<?php defined('BASEPATH') or die("ip anda sudah tercatat oleh sistem kami");
