<style type="text/css">
   .upper { text-transform: uppercase; }
   .lower { text-transform: lowercase; }
   .app-sidebar__user-name   { text-transform: capitalize; }
   .small { font-variant:   small-caps; }
</style>

<?php
$nama_user = $user['nama_user'] ;
$namapendek = strtolower($nama_user);
// 
?>
   
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="../assets/img/avatar/avatar-1.png" width='50'alt="User Image">
        <div>
          <p class="app-sidebar__user-name"class="cap"><?= $namapendek ?></p>
          <p class="app-sidebar__user-designation"><small> Akses "<?= $user['akses'] ?>"</small></p>
        </div>
      </div>
	<ul class="app-menu">
	 <li><a class="app-menu__item active bg-info" href="."><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
	<?php if ($user['akses'] == "admin") { ?>
       
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Kelembagaan</span><i class="treeview-indicator fa fa-arrow-circle-down"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="?pg=profil_lembaga"><i class="icon fa fa-circle-o"></i> Profil Lembaga</a></li>
			<li><a class="treeview-item" href="?pg=pengguna"><i class="icon fa fa-circle-o"></i> Data Pengguna</a></li>
            <li><a class="treeview-item" href="?pg=kelas"><i class="icon fa fa-circle-o"></i> Data Kelas</a></li>
			<li><a class="treeview-item" href="?pg=guru"><i class="icon fa fa-circle-o"></i> Data Guru</a></li>
			<li><a class="treeview-item" href="?pg=jurusan"><i class="icon fa fa-circle-o"></i> Data Jurusan</a></li>
          </ul>
        </li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-credit-card"></i><span class="app-menu__label">Akademik</span><i class="treeview-indicator fa fa-arrow-circle-down"></i></a>
          <ul class="treeview-menu">
            
			
            <li><a class="treeview-item" href="?pg=masuk"><i class="icon fa fa-circle-o"></i>Mutasi Masuk</a></li>
			<li><a class="treeview-item" href="?pg=pindah"><i class="icon fa fa-circle-o"></i>Mutasi Keluar</a></li>
			<li><a class="treeview-item" href="?pg=luluskan"><i class="icon fa fa-circle-o"></i>Kelulusan</a></li>
			
          </ul>
        </li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-cubes"></i><span class="app-menu__label">Administrasi</span><i class="treeview-indicator fa fa-arrow-circle-down"></i></a>
          <ul class="treeview-menu">
            
			<li><a class="treeview-item" href="?pg=bukuinduk"><i class="icon fa fa-circle-o"></i>Buku induk</a></li>
			<li><a class="treeview-item" href="?pg=kartupelajar"><i class="icon fa fa-circle-o"></i>Kartu Pelajar</a></li>
			<li><a class="treeview-item" href="?pg=cetak_data"><i class="icon fa fa-circle-o"></i>Cetak Data</a></li>
          </ul>
        </li>
		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user"></i><span class="app-menu__label">Data Siswa</span><i class="treeview-indicator fa fa-arrow-circle-down"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="?pg=siswa"><i class="icon fa fa-circle-o"></i> Semua Siswa</a></li>
			<li><a class="treeview-item" href="?pg=ubahkelas"><i class="icon fa fa-circle-o"></i>Belum Masuk Kelas</a></li>
            
		  <?php
                            $query = mysqli_query($koneksi, "select * from jenjang");
                            $no = 0;
                            while ($jenjang = mysqli_fetch_array($query)) {
													
                                $no++;
                            ?>
            <li><a class="treeview-item" href="?pg=ubahkelas&id=<?= enkripsi($jenjang['id_jenjang']) ?>"><i class="icon fa fa-circle-o"></i> <?= $jenjang['kode'] ?>-<?= $jenjang['nama_jenjang'] ?></a></li>
			<?php } ?>
			
			
            
          </ul>
        </li>

		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user-circle-o"></i><span class="app-menu__label">Data Alumni</span><i class="treeview-indicator fa fa-arrow-circle-down"></i></a>
          <ul class="treeview-menu">
		  <li><a class="treeview-item" href="?pg=alumni"><i class="icon fa fa-circle-o"></i> Home </a></li>
		  <?php $query = mysqli_query($koneksi, "select * from siswa  where status ='3' group by tahun_lulus  ");
												 $no = 0;
												while ($tahun_lulus = mysqli_fetch_array($query)) {
													$no++;
													
													
												?>
							
            <li><a class="treeview-item" href="?pg=alumni&tahun_lulus=<?= $tahun_lulus['tahun_lulus'] ?>"><i class="icon fa fa-circle-o"></i> <?= $tahun_lulus['tahun_lulus'] ?></a></li>
			<?php } ?>
            
          </ul>
        </li>
		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user"></i><span class="app-menu__label">Data PPDB</span><i class="treeview-indicator fa fa-arrow-circle-down"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="?pg=ppdb"><i class="icon fa fa-circle-o"></i>Beranda</a></li>
			<li><a class="treeview-item" href="?pg=daftar"><i class="icon fa fa-circle-o"></i> Semua Pendaftar</a></li>
			<li><a class="treeview-item" href="?pg=diterima"><i class="icon fa fa-circle-o"></i>Pendaftar DiTerima</a></li>
			
          </ul>
        </li>
		<br>
		<center> <button data-id="" class=" btn btn-sm btn-danger">Versi <?= $versi ?></b></button></center>
     
	  
	  <?php } ?>
	  <?php if ($user['akses'] == "ppdb") { ?>
		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user"></i><span class="app-menu__label">Data PPDB</span><i class="treeview-indicator fa fa-arrow-circle-down"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="?pg=ppdb"><i class="icon fa fa-circle-o"></i>Beranda</a></li>
			<li><a class="treeview-item" href="?pg=daftar"><i class="icon fa fa-circle-o"></i> Semua Pendaftar</a></li>
			<li><a class="treeview-item" href="?pg=diterima"><i class="icon fa fa-circle-o"></i>Pendaftar DiTerima</a></li>
			
          </ul>
        </li>
      
		
	  
	  <?php } ?>
	  
	    </ul>
