<?php ob_start();
require "../../config/database.php";
require "../../config/function.php";
require "../../config/functions.crud.php";
include "../../assets/modules/phpqrcode/qrlib.php";
session_start();
if (!isset($_SESSION['id_user'])) {
    die('Anda tidak diijinkan mengakses langsung');
}
$siswa = fetch($koneksi, 'siswa');
$homeurl = "http://" . $_SERVER['HTTP_HOST'] ;
$laman ='file_kartu_pelajar.php';
//isi qrcode jika di scan
$tgl_cetak = $setting['tgl_cetak'];
$hariini = date('Y-m-d');
$hariini = date('Y-m-d');
$tahun1 = date('Y');
$tahun2 = date('Y')+1;


?>



<HTML>
<HEAD>
   
    <title>Cetak Kartu Pelajar</title>
</head>
<?php if (isset($_GET['id']) == '') { ?>
<?php } else { ?>
<?php $jenjang = fetch($koneksi, 'jenjang', ['id_jenjang' => dekripsi($_GET['id'])]) ?>
<body style="font-family: arial;font-size: 12px;position:absolute;">
 <?php
                            $query = mysqli_query($koneksi, "select * from siswa where kelas='$jenjang[id_jenjang]'");
                            $no = 0;
                            while ($siswa = mysqli_fetch_array($query)) {
								
                                $tgl_lahirsiswa = $siswa['tgl_lahir'];
								$kelas = fetch($koneksi, 'jenjang', ['id_jenjang' => $siswa['kelas']]);
								$tempdir = "../temp/"; //Nama folder tempat menyimpan file qrcode
									if (!file_exists($tempdir)) //Buat folder bername temp
										mkdir($tempdir);

									//isi qrcode jika di scan
									
									$codeContents = $homeurl . '/' . $laman . '?' . 'id=' . enkripsi($siswa['nisn']);
									

									//simpan file kedalam temp
									//nilai konfigurasi Frame di bawah 4 tidak direkomendasikan

									QRcode::png($codeContents, $tempdir . $siswa['nis'] . '.png', QR_ECLEVEL_M, 4);
                                $no++;
                            ?>
							
    <div style="width: 750px;height: 243px;margin: 0px;">
    <img style="position: absolute;padding-left: 0px;padding-top: 0px;" class="img-responsive img" alt="Responsive image" src="../../<?= $setting['template'] ?>" width="750px" height= "243px">

   <p style="position: relative;padding-left: 170px;padding-top: 70px; "><b>KARTU PELAJAR</b></p>
   <?php if ($siswa['foto'] == null) { ?> 
						
                        <div  style=" border: 2px solid black;width: 20mm;height: 27mm;text-align: center;position: absolute;margin-left: 20px;margin-top: -5px;"><span><br><br><br>Foto<br>2x3</div>
                       
						<?php } else { ?> 
						<img style="border: 1px solid #ffffff;position: absolute;margin-left: 20px;margin-top: -15px;" src="../../<?= $siswa['foto'] ?>" width="80px">
						<?php } ?>
    <img style="position: absolute;padding-left: 420px;margin-top: 50px;" class="img-responsive img" alt="Responsive image" src="../temp/<?= $siswa['nis'] ?>.png" width="65px">
	
        <table style="margin-top: -10px;padding-left: 120px; position: relative;font-family: arial;font-size: 11px;">
          
			<tr>
                <td>Nama</td>
                <td>:</td>
                <td><b><?= $siswa['nama_siswa'] ?></b></td>
            </tr>
			<tr>
                <td>NIS Lokal</td>
                <td>:</td>
                <td><?= $siswa['nis'] ?></td>
            </tr>
			<tr>
                <td>NISN</td>
                <td>:</td>
                <td><?= $siswa['nisn'] ?></td>
            </tr>
            </tr><tr>
                <td>Tempat Lahir</td>
                <td>:</td>
                <td><?= $siswa['tempat_lahir'] ?></td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>:</td>
                <td><?php echo tgl_indo("$tgl_lahirsiswa");?></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>:</td>
                <td><?php if ($siswa['jk'] == 'L') { ?> Laki Laki <?php } else { ?> Perempuan <?php } ?></td>
            </tr>
            
            <tr>
                <td>Berlaku</td>
                <td>:</td>
                <td>Selama Menjadi Siswa</td>
            </tr>
        </table>
        <p style="padding-left: 10px;font-size: 8px; font-family: arial;position: absolute;">Alamat: <?= $setting['alamat'] ?> Kecamatan <?= $setting['kec'] ?> Kecamatan <?= $setting['kec'] ?><br> Email: <?= $setting['email'] ?> | Telp. <?= $setting['no_telp'] ?> </p>
        <p style="position: absolute;margin-top: -200px;padding-left: 520px;padding-top: 17px;"><b><?= $setting['header'] ?></b>
       
<ol style="position: absolute;margin-top: -150px;padding-left: 370px;color: #0000000; font-family: arial;font-size: 11px;text-align: justify;padding-right: 30px">
                      <?= $setting['isi'] ?>
                    </ol>
        </p>
        <p style="position: absolute;padding-left: 550px;margin-top: -80px;font-size: 11px; font-family: arial;">
           <?= $setting['kec'] ?>, <?php echo tgl_indo("$tgl_cetak");?>       </p>
		<img style="position: absolute;padding-left: 500px;margin-top: -70px;" class="img-responsive img" alt="Responsive image" src="../../<?= $setting['stempel'] ?>" width="120px">
        <img style="position: absolute; padding-left: 535px;margin-top: -55px;" class="img-responsive img" alt="Responsive image" src="../../<?= $setting['ttd'] ?>" width="100px">
        
		<p style="position: absolute;padding-left: 550px;margin-top: -60px;font-size: 11px; font-family: arial;">Mengetahui, <br>Kepala Madrasah</p>
        <p style="position: absolute;padding-left: 550px;margin-top: -15px;font-size: 11px; font-family: arial;"><b><u><?= $setting['kepala'] ?></u></b><br>NIP. <?= $setting['nip'] ?></p>
</div>
<?php } ?>
<?php } ?>
</body>
</html>
