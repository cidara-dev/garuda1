<?php defined('BASEPATH') or die("ip anda sudah tercatat oleh sistem kami") ?>
<div class="app-title">
        <div>
          <h1><i class="fa fa-bank"></i>Pengatuaran Kartu Pelajar</h1>
          
        </div>
        
 </div>

 
		<div class="row">
        <div class="col-md-6">
          <div class="tile">
             <div class="tile-body">
              	<form id="form-setting">
								<div class='box box-solid'>
									<div class='box-header with-border'>
										<h3 class='box-title'>Pengaturan Cetak</h3>
										
									</div><!-- /.box-header -->
									<div class='box-body'>
										
										
										
										<div class='form-group'>
											<div class='row'>
												<div class='col-md-12'>
													<label>Template Kartu </label>
													<p style="font-family: arial;font-size: 11px"> ( Ukuran 750px X 243px atau 165mm X 54mm) Untuk Mengedit Template ini Silahkan  Login Ke <a href="https://www.canva.com"target="_blank" rel="nofollow" title="Website Canva">Canva</a>  Lalu <a href="https://www.canva.com/design/DAEpP4qTAAA/hhOVFk2sIsJe1f1ZlpPG0Q/view?utm_content=DAEpP4qTAAA&utm_campaign=designshare&utm_medium=link&utm_source=sharebutton&mode=preview"target="_blank" rel="nofollow" title="Template Kartu Pelajar">Klik Disini</a> </p>
													<input type='file' name='template' class='form-control' />
												</div>
												<div class="col-sm-6 col-md-12">
													&nbsp;<br />
													 <img src="../<?= $setting['template'] ?>" class="img-thumbnail" width="800">
												</div>
											</div>
										</div>
										
										<div class='form-group'>
											<div class='row'>
												<div class="col-sm-6 col-md-6">
													<label>Stempel</label>
													<input type='file' name='stempel' class='form-control' />
												</div>
												<div class="col-sm-6 col-md-6">
													&nbsp;<br />
													 <img src="../<?= $setting['stempel'] ?>" class="img-thumbnail" width="100">
												</div>
											</div>
										</div>
										<div class='form-group'>
											<div class='row'>
												<div class="col-sm-6 col-md-6">
													<label>Tandatangan</label>
													<input type='file' name='ttd' class='form-control' />
												</div>
												<div class="col-sm-6 col-md-6">
													&nbsp;<br />
													 <img src="../<?= $setting['ttd'] ?>" class="img-thumbnail" width="100">
												</div>
											</div>
										</div>
										<div class='form-group'>
											<label>Tanggal Cetak</label>
											<input type='date' name='tgl_cetak' value="<?= $setting['tgl_cetak'] ?>" class='form-control' required='true' />
										</div>
										
									</div><!-- /.box-body -->
								</div><!-- /.box -->
								<div class="tile-footer">
							  <button class="btn btn-primary" type='submit' id="save-btn"><i class="fa fa-fw fa-lg fa-check-circle"></i>Simpan</button>&nbsp;&nbsp;&nbsp;<a class="btn btn-secondary" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
							</div>
							</form>
						</div>
						
			</div>
						<script>
						$('.custom-file-input').on('change', function() {
							let fileName = $(this).val().split('\\').pop();
							$(this).next('.custom-file-label').addClass("selected").html(fileName);
						});
						$('#form-setting').on('submit', function(e) {
							e.preventDefault();
							$.ajax({
								type: 'post',
								url: 'mod_kartu/crud_setting.php?pg=ubah',
								data: new FormData(this),
								processData: false,
								contentType: false,
								cache: false,
								beforeSend: function() {
									$('form button').on("click", function(e) {
										e.preventDefault();
									});
								},
								success: function(data) {

									swal({
									title: 'Terimakasih',
									text: 'Data Berhasil Disimpan!',
									type: 'success',
									buttons: false,
									});
									setTimeout(function() {
										window.location.reload();
									}, 1000);


								}
							});
						});
					</script>
		</div>
		<div class="col-md-6">
			<div class="tile">
			<div class='box-header with-border'>
										<h3 class='box-title'>Pengaturan Konten</h3>
										
									</div><!-- /.box-header -->
             <div class="tile-body">
				<div class='box box-solid'>
				<form id="form-setting2">
				<div class='form-group'>
					<label>Header</label>
					<input type='text' name='header' value="<?= $setting['header'] ?>" class='form-control' required='true' />
				</div>
				<div class='form-group'>
					<label>Isi</label>
					<textarea name="isi" class="summernote"><?= $setting['isi'] ?></textarea>
					<script> 
							$(document).ready(function() {
							$('.summernote').summernote();
						});
					</script>
				</div>
				<div class="tile-footer">
				  <button class="btn btn-primary" type='submit' id="save-btn"><i class="fa fa-fw fa-lg fa-check-circle"></i>Simpan</button>&nbsp;&nbsp;&nbsp;<a class="btn btn-secondary" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
				</div>
				</form>
					<script>
						
						$('#form-setting2').on('submit', function(e) {
							e.preventDefault();
							$.ajax({
								type: 'post',
								url: 'mod_kartu/crud_setting.php?pg=ubah2',
								data: new FormData(this),
								processData: false,
								contentType: false,
								cache: false,
								beforeSend: function() {
									$('form button').on("click", function(e) {
										e.preventDefault();
									});
								},
								success: function(data) {

									swal({
									title: 'Terimakasih',
									text: 'Data Berhasil Disimpan!',
									type: 'success',
									buttons: false,
									});
									setTimeout(function() {
										window.location.reload();
									}, 1000);


								}
							});
						});
					</script>
				</div>
				</div>
				</div>
				
				
		</div>
	<div class="col-md-12">
		<div class="tile">
			<div class="tile-body">
				<h3 class='box-title'>Preview</h3>
			</div><!-- /.box-header -->
			<div class="tile-body">
				<center><iframe src="mod_kartu/example.php" width="100%" height="255" align="center"></iframe><center>
			</div>
		</div>
	</div>
	<div class="col-md-12">
	  <div class="tile">
			 <div class="tile-body">
						<div class='box box-solid'>
							<div class='box-header with-border'>
								<h3 class='box-title'>Cetak Kartu Per Kelas</h3>
								
							</div>
				</div>
				<hr>
				
			</div>
										

									
				<div class='col-md-12'>
					<div class="table-responsive">
					 <table style="font-size: 12px" class="table table-striped table-sm" id="example">
						<thead>
									<tr>
										<th class="text-center">
											No
										</th>
										<th>Tingkat</th>
										<th>Nama Rombel</th>
										<th>Siswa</th>
										<th>Cetak</th>
									   
									</tr>
								</thead>
													<tbody>
									<?php
									$query = mysqli_query($koneksi, "select * from jenjang");
									$no = 0;
									while ($jenjang = mysqli_fetch_array($query)) {
										$hitung = rowcount($koneksi, 'siswa', ['kelas' => $jenjang['id_jenjang']]);
										$no++;
									?>
										<tr>
											<td><?= $no; ?></td>
											<td><?= $jenjang['kode'] ?></td>
											<td> <?= $jenjang['nama_jenjang'] ?></td>
											<td><?= $hitung; ?></td>
											<td>
											  <iframe name='cetakktp<?= $no; ?>' src='mod_kartu/ktp.php?id=<?= enkripsi($jenjang['id_jenjang']) ?>' style='border:none;width:1px;height:1px;'></iframe><button onclick="frames['cetakktp<?= $no; ?>'].print()" class='btn  btn-flat btn-success'><i class='fa fa-print'></i></button>		  
											</td>
										   
										</tr>
									   
									<?php }
									?>


								</tbody>
					</table>
					</div>
				</div>
				</div>
		
	</div>		
   