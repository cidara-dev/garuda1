<?php ob_start();
require "../../config/database.php";
require "../../config/function.php";
require "../../config/functions.crud.php";

?>

<body style="font-family: arial;font-size: 12px;position:absolute;">
 							
    <div style="width: 750px;height: 243px;margin: 0px;">
     <img style="position: absolute;padding-left: 0px;padding-top: 0px;" class="img-responsive img" alt="Responsive image" src="../../<?= $setting['template'] ?>" width="750px" height= "243px">

   <p style="position: relative;padding-left: 170px;padding-top: 70px; "><b>KARTU PELAJAR</b></p>
    
						<img style="border: 1px solid #ffffff;position: absolute;margin-left: 20px;margin-top: -15px;" src="../../assets/upload/foto_siswa/siswa433.png" width="80px">
						    <img style="position: absolute;padding-left: 420px;margin-top: 60px;" class="img-responsive img" alt="Responsive image" src="../temp/0044451503.png" width="65px">
	
        <table style="margin-top: -10px;padding-left: 120px; position: relative;font-family: arial;font-size: 11px;">
          
			<tr>
                <td>Nama</td>
                <td>:</td>
                <td><b>MUHAMAD JAMIL</b></td>
            </tr>
			<tr>
                <td>NIS Lokal</td>
                <td>:</td>
                <td>131265010003190029</td>
            </tr>
			<tr>
                <td>NISN</td>
                <td>:</td>
                <td>0044451503</td>
            </tr>
            </tr><tr>
                <td>Tempat Lahir</td>
                <td>:</td>
                <td>Ruhui Rahayu</td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>:</td>
                <td>20 April 2004</td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>:</td>
                <td> Laki Laki </td>
            </tr>
            
            <tr>
                <td>Berlaku</td>
                <td>:</td>
                <td>Selama Menjadi Siswa</td>
            </tr>
        </table>
        <p style="padding-left: 10px;font-size: 8px; font-family: arial;position: absolute;">Alamat: <?= $setting['alamat'] ?> Kecamatan <?= $setting['kec'] ?><br> Email: <?= $setting['email'] ?> | Telp. <?= $setting['no_telp'] ?> | https://<?= $setting['web'] ?></p>
        <p style="position: absolute;margin-top: -200px;padding-left: 520px;padding-top: 17px;"><b><?= $setting['header'] ?></b>
       
<ol style="position: absolute;margin-top: -150px;padding-left: 370px;color: #0000000; font-family: arial;font-size: 11px;text-align: justify;padding-right: 30px">
                      <?= $setting['isi'] ?>
                    </ol>
        </p>
        <p style="position: absolute;padding-left: 550px;margin-top: -70px;font-size: 11px; font-family: arial;">
           Tanjung Selor, 14 Juli 2020       </p>
		<img style="position: absolute;padding-left: 520px;margin-top: -60px;" class="img-responsive img" alt="Responsive image" src="../../<?= $setting['stempel'] ?>" width="75px">
        <img style="position: absolute; padding-left: 535px;margin-top: -55px;" class="img-responsive img" alt="Responsive image" src="../../<?= $setting['ttd'] ?>" width="100px">
        
		<p style="position: absolute;padding-left: 550px;margin-top: -60px;font-size: 11px; font-family: arial;">Mengetahui, <br>Kepala Madrasah</p>
        <p style="position: absolute;padding-left: 550px;margin-top: -15px;font-size: 11px; font-family: arial;"><b><u><?= $setting['kepala'] ?></u></b><br>NIP. <?= $setting['nip'] ?></p>
</div>
</body>	


