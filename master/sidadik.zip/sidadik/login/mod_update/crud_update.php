<?php
require("../../config/excel_reader.php");
require("../../config/database.php");
require("../../config/function.php");
require("../../config/functions.crud.php");
session_start();
if (!isset($_SESSION['id_user'])) {
    die('Anda tidak diijinkan mengakses langsung');
}

if ($pg == 'update') {  
      $directory = '../../.';
$url  = 'https://data.ma.nwkaltara.web.id/update02.zip';
$path = $directory.'/update';  
$fp = fopen($path, 'w');
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_FILE, $fp);
$data = curl_exec($ch);
$zip = new ZipArchive;
                if($zip->open($path)){
                    $zip->extractTo($directory);
                    $zip->close();
                }
if($data){
 echo 'File backup sudah di instal';
}
else{
 echo 'Yah... Gagal Mengambil File';
}
curl_close($ch);
fclose($fp);
 } 	 