<?php
require "config/database.php";
require "config/function.php";
require "config/functions.crud.php";
require "login/versi.php";
$tahun1 = date('Y');
$tahun2 = date('Y')+1;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport" />
         <title>DATA ALUMNI | <?= $setting['nama_sekolah'] ?></title>
		 <!-- META DISKRIPSI-->
		<meta name="description" content="Mari bergabung Bersama Kami di <?= $setting['nama_sekolah'] ?>, Pendaftaran Peserta didik Baru Tahun <?= date('Y') ?> Kembali dibuka ">
		<meta name="keywords" content="simasapp v.1.1,simas madrasah, simas sekolah, web simas,"/>

        <link rel="stylesheet" href="assets/modules/izitoast/css/iziToast.min.css">
                <link href="assets/css/front2.min.css" rel="stylesheet" />
        <link rel="shortcut icon" href="<?= $setting['logo'] ?>" >		
		 <link rel="stylesheet" href="assets/css/1.css">
		 <link rel="stylesheet" href="assets/css/2.css">
		 <link rel="stylesheet" href="assets/css/3.css">
		 <link rel="stylesheet" href="assets/css/3.css">
        
		 <link rel="stylesheet" href="assets/css/components2.css">
		
				
      
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    
    <!-- Start GA -->
    
    
	 <?php
	$akhir  = new DateTime($setting['tgl_pengumuman']); //Waktu awal
	$awal = new DateTime(); // Waktu sekarang atau akhir
	$diff  = $awal->diff($akhir);

	?>
	<style type="text/css">
   .upper { text-transform: uppercase; }
   .lower { text-transform: lowercase; }
   .cap   { text-transform: capitalize; }
   .small { font-variant:   small-caps; }
</style>
    </head>

    
    <body data-spy="scroll" data-target="#menu" data-offset="100">
        <div class="home-wrapper" id="home">
            <div class="home-header">
                <div class="container p-0">
                    <nav class="navbar navbar-expand-lg navbar-light" id="navbar-header">
                        <a class="navbar-brand" href="javascript:;">
                            <img src="<?= $setting['logo'] ?>" height="75" />
							
							
                            <div class="home-header-text d-none d-sm-block">
                                <h5>APLIKASI DATABASE SISWA</h5>
                                <h6><?= $setting['nama_sekolah'] ?></h6>
                                <h6>Tahun Pelajaran <?= $tahun1 ?>/<?= $tahun2 ?></h6>
                            </div>
                            <span class="logo-mini-unbk d-block d-sm-none">DATABASE </span>
                            <span class="logo-mini-tahun d-block d-sm-none">_ONLINE</span>
                        </a>
						
						
						
						<hr>
						
                        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="menu">
                           
							<ul class="navbar-nav ml-auto">
                                <li class="nav-item ">
                                    <a class="nav-link" href="./#home" id="link-home">Home</a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="datasiswa.php" id="link-tentang">Data Siswa</a>
                                </li>
                                <li class="nav-item active">
                                    <a class="nav-link" href="dataalumni.php" id="link-statistik">Data Alumni</a>
                                </li>
                               
								 <li class="nav-item">
                                    <a class="nav-link" href="./login" id="link-persyaratan">Admin</a>
                                </li>
								
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            </div>
        </div>
        <div class="home-title">
            <div class="container">
			
            
				<form id="ubah">
						<div class="form-row align-items-center">
								<div class="form-group">
												
									<select class="form-control select2" style="width: 100%" name="tahun_lulus" id="jurusan" required>
										<option value="">Pilih Angkatan Alumni</option>
										<?php $qu = mysqli_query($koneksi, "select * from siswa where status='3' group by tahun_lulus");
										while ($tahun = mysqli_fetch_array($qu)) {
										?>
											<option value="<?= enkripsi($tahun['tahun_lulus']) ?>"> Angkatan <?= $tahun['tahun_lulus'] ?></option>
										<?php } ?>

									</select>
								</div>
							
							<div class="form-group">
								<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> CARI</button>
							</div>
						</div>
					</form>
		</div>	
        </div>
		
		
		<?php if (isset($_GET['tahun_lulus']) == '') { ?>
        <div class="home-content-wrapper ">
            <div class="container">
                <div class="row">
	
                    

					
              <div class="col-md-12 mb-3">
              <div class="card bg-primary">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    
                    <div class="mt-12">
                      
					  <h3>Data Semua Alumni </h3>
					  
                    </div>
                  </div>
                </div>
              </div>
              <br>
			  <hr>
					
					
					    <table style="font-size: 12px" class="table table-striped table-sm table-bordered" cellspacing="0" id="sampleTable" width="100%">
                        
							<div class="row">
								
								<?php
								 $query = mysqli_query($koneksi, "select * from siswa where status in(3)");
								$no = 0;
								while ($siswa = mysqli_fetch_array($query)) {
									$kelas = fetch($koneksi, 'jenjang', ['id_jenjang' => $siswa['kelas']]);
									$nisn = $siswa['nisn'];
									$tgl_lahirsiswa = $siswa['tgl_lahir'];
									$tampil_nisn    =substr($nisn, 0, 5);
									$no++;
								   
								?>
									
									<div class="col-md-6 mb-4 profile-alumni">
								<div class="card rounded-0">
								<div class="row">
								<div class="col-md-3" valign="center">
										<center><?php if ($siswa['foto'] == null) { ?> 
						
										<div  style=" border: 2px solid black;width: 30mm;height: 40mm;text-align: center;"><span><br><br><br>Foto<br>3x4</div>
									   
										<?php } else { ?> 
										<img class="img" src="<?= $siswa['foto'] ?>" ec="H" style="width: 30mm; background-color: white; color: black;">
										<?php } ?>	</center>				
								</div>
									<div class="col-md-9">
										<div class="card-body">
											<dl class="row">
												<dt class="col-sm-5"><b>Nama Lengkap</b></dt>
												<dd class="col-sm-7"><b><?= $siswa['nama_siswa'] ?></b></dd>
												<dt class="col-sm-5">NISN</dt>
												<dd class="col-sm-7"><?= $tampil_nisn?>XXX</dd>

												<dt class="col-sm-5">NIS</dt>
												<dd class="col-sm-7"><?= $siswa['nis'] ?></dd>

												<dt class="col-sm-5">Jenis Kelamin</dt>
												<dd class="col-sm-7"><?php if ($siswa['jk'] == 'L') { ?> Laki Laki <?php } else { ?> Perempuan <?php } ?></dd>

												<dt class="col-sm-5">Tahun Lulus</dt>
												 <?php if ($siswa['tahun_lulus'] == null) { ?>
												 <dd class="col-sm-7">-</dd>
												<?php } else { ?>
												<dd class="col-sm-7"><?= $siswa['tahun_lulus'] ?></dd>
												
												<?php } ?>
												

												

												
											</dl>
										</div>
									</div>
								
								   </div>
								</div></div>
								<?php }
								?>
								
							
						</table>
					
					</div>
					
			   
				
				</div>
			
			<hr>

		</div>


        </div>
        </div>
       <?php } else { ?>
		<?php $kelasq = fetch($koneksi, 'siswa', ['tahun_lulus' => dekripsi($_GET['tahun_lulus'])]) ?>
        <div class="home-content-wrapper ">
            <div class="container">
                <div class="row">
	
                    

					<div class="col-md-12">
					<div class="card bg-primary">
					<div class="card-body">
					  <div class="d-flex flex-column align-items-center text-center">
						
						<div class="mt-12">
						  
						  <h3>Data Alumni Tahun <?= $kelasq['tahun_lulus'] ?></h3>
						  
						</div>
					  </div>
					</div>
				  </div>
				  <br>
				  <hr>
					
					    <table style="font-size: 12px" class="table table-striped table-sm table-bordered" cellspacing="0" id="sampleTable" width="100%">
                        
							<div class="row">
								
								<?php
								$query = mysqli_query($koneksi, "select * from siswa where tahun_lulus='$kelasq[tahun_lulus]'");
								$no = 0;
								while ($siswa = mysqli_fetch_array($query)) {
									$kelas = fetch($koneksi, 'jenjang', ['id_jenjang' => $siswa['kelas']]);
									$nisn = $siswa['nisn'];
									$tgl_lahirsiswa = $siswa['tgl_lahir'];
									$tampil_nisn    =substr($nisn, 0, 5);
									$no++;
								   
								?>
									
									<div class="col-md-6 mb-4 profile-alumni">
								<div class="card h-100 border border-secondary rounded-0">
								<div class="row">
								<div class="col-md-3" valign="center">
										<center><?php if ($siswa['foto'] == null) { ?> 
						
										<div  style=" border: 2px solid black;width: 30mm;height: 40mm;text-align: center;"><span><br><br><br>Foto<br>3x4</div>
									   
										<?php } else { ?> 
										<img class="img" src="<?= $siswa['foto'] ?>" ec="H" style="width: 30mm; background-color: white; color: black;">
										<?php } ?>	</center>				
								</div>
									<div class="col-md-9">
										<div class="card-body pt-2 pb-2">
											<dl class="row">
												<dt class="col-sm-5"><b>Nama Lengkap</b></dt>
												<dd class="col-sm-7"><b><?= $siswa['nama_siswa'] ?></b></dd>
												<dt class="col-sm-5">NISN</dt>
												<dd class="col-sm-7"><?= $tampil_nisn?>XXX</dd>

												<dt class="col-sm-5">NIS</dt>
												<dd class="col-sm-7"><?= $siswa['nis'] ?></dd>

												<dt class="col-sm-5">Jenis Kelamin</dt>
												<dd class="col-sm-7"><?php if ($siswa['jk'] == 'L') { ?> Laki Laki <?php } else { ?> Perempuan <?php } ?></dd>

												<dt class="col-sm-5">Tahun Lulus</dt>
												 <?php if ($siswa['tahun_lulus'] == null) { ?>
												 <dd class="col-sm-7">-</dd>
												<?php } else { ?>
												<dd class="col-sm-7"><?= $siswa['tahun_lulus'] ?></dd>
												
												<?php } ?>
												

												

												
											</dl>
										</div>
									</div>
								
								   </div>
								</div></div>
								<?php }
								?>
								
							
						</table>
					
					</div>
					
			   
				
				</div>
			
			<hr>

		</div>


        </div>
        </div>            
         <?php }
								?>      
        
    <div class="home-footer"><div class="container text-center">Copyright ©<?= date('Y') ?> <?= $setting['nama_sekolah'] ?> | <?= $create ?></div></div>
       
		
         <!-- Vendor -->
        <script src="vendor/jquery-3.2.1.min.js"></script>
        <script src="vendor/jquery.form.min.js"></script>
        <script src="vendor/bootstrap.min.js"></script>
        <script src="vendor/popper.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
    <script src="assets/modules/izitoast/js/iziToast.min.js"></script>
	<script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
   
    </body>
	<script>
    $('#form-login').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'user/crud_web.php?pg=login',
            data: $(this).serialize(),
            beforeSend: function() {
                $('#btnsimpan').prop('disabled', true);
            },
            success: function(data) {
                var json = $.parseJSON(data);
                $('#btnsimpan').prop('disabled', false);
                if (json.pesan == 'ok') {
                    iziToast.success({
                        title: 'Mantap!',
                        message: 'Login Berhasil',
                        position: 'topRight'
                    });
                    setTimeout(function() {
                        window.location.href = "user";
                    }, 2000);

                } else {
                    iziToast.error({
                        title: 'Maaf!',
                        message: json.pesan,
                        position: 'topCenter'
                    });
                }
                //$('#bodyreset').load(location.href + ' #bodyreset');
            }
        });
        return false;
    });
 
</script>
</body>

</html>