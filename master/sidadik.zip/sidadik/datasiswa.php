<?php
require "config/database.php";
require "config/function.php";
require "config/functions.crud.php";
require "login/versi.php";
$tahun1 = date('Y');
$tahun2 = date('Y')+1;
?>

<!DOCTYPE html>
<html lang="en">

<head>
<base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="google" content="notranslate" />
    <meta name="description" content="Aplikasi Database | <?= $setting['nama_sekolah'] ?>">
    <meta name="author" content="Nasrul Creative">
	<meta name="theme-color" content="#317EFB"/>
    <meta name="keyword" content="Aplikasi database,database madrasah,database sekolah">
	<meta name="msapplication-navbutton-color" content="#4285f4">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="msapplication-TileColor" content="#ffffff">
    
    <meta name="theme-color" content="#ffffff">
	
    <title>DATA SISWA | <?= $setting['nama_sekolah'] ?> </title>
   
		<link rel="icon" type="image/png" sizes="192x192" href="assets/database.png">
		
		<link rel="stylesheet" type="text/css" href="css/main2.css">
		<meta name="keywords" content="simasapp v.1.1,simas madrasah, simas sekolah, web simas,"/>
		<link rel="stylesheet" href="assets/modules/izitoast/css/iziToast.min.css">
        <link href="assets/css/front2.min.css" rel="stylesheet" />
        <link rel="shortcut icon" href="<?= $setting['logo'] ?>" >		
		 <link rel="stylesheet" href="assets/css/1.css">
		 <link rel="stylesheet" href="assets/css/2.css">
		 <link rel="stylesheet" href="assets/css/3.css">
		
		 <link rel="stylesheet" href="assets/css/components2.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<!--===============================================================================================-->
	
	 <link href="/assets/img/logo.png" rel="shortcut icon" />
		

    
    </head>



<body data-spy="scroll" data-target="#navbar-header" data-offset="100">
    <div class="home-wrapper" id="home">
        <div class="home-header">
            <div class="container p-0">
                <nav class="navbar navbar-expand-lg navbar-light" id="navbar-header">
                    <a class="navbar-brand" href="javascript:;">
                            <img src="<?= $setting['logo'] ?>" height="75" />
                            <div class="home-header-text d-none d-sm-block">
                                <h5>APLIKASI DATABASE SISWA</h5>
                                <h6><?= $setting['nama_sekolah'] ?></h6>
                                <h6>Tahun Pelajaran <?= $tahun1 ?>/<?= $tahun2 ?></h6>
                            </div>
                            <span class="logo-mini-unbk d-block d-sm-none">DATABASE </span>
                            <span class="logo-mini-tahun d-block d-sm-none">_ONLINE</span>
                        </a>
                    <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#menu"
                        aria-controls="menu" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="menu">
                        <ul class="navbar-nav ml-auto">
                                <li class="nav-item ">
                                    <a class="nav-link" href="." id="link-home">Home</a>
                                </li>
								
                                <li class="nav-item active">
                                    <a class="nav-link" href="datasiswa.php" id="link-tentang">Data Siswa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="dataalumni.php" id="link-statistik">Data Alumni</a>
                                </li>
                               
								 <li class="nav-item">
                                    <a class="nav-link" href="./login" id="link-persyaratan">Admin</a>
                                </li>
								
                            </ul>
                    </div>
                </nav>
            </div>
        </div>
        <div class="home-title">
            <div class="container"><h5 class="post-title" id="sekolah">
			<span class="fa fa-user"></span><span>Data Siswa Aktif</span>
		</h5>            
		</div>
        </div>
        <div class="home-content-wrapper mb-5">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="card card-login mb-5">
                            <div class="card-body">
                                <h3 class="mb-3"><center>LOGIN SISWA</center></h3>
                               <form id="form-login" class="login100-form validate-form">
                                    <div class="form-group">
                                        <span class="fa fa-user"></span>
                                        <input class="form-control" type="text" name="username"placeholder="Masukkan NISN" required>
                                    </div>
                                    <div class="form-group">
                                        <span class="fa fa-key"></span>
                                         <input class="form-control" type="password"  name="password"placeholder="Password"required>
                                    </div>
                                    
                                    
                                    <button type="submit" id="btnsimpan"  class="btn btn-primary btn-block btn-login">
                                        Masuk
                                    </button>
                                </form>
								
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-9">
				<div class="tile ">
			   <div class="row">
					<div class="col-md-8">
					 
					
					</div>
					
					
				  
					<div class="col-md-4">
						<form id="ubah">
							<div class="form-row align-items-center">
									<div class="form-group">
													
										<select class="form-control select2" style="width: 100%" name="id" id="jurusan" required>
											<option value="">Pilih Kelas Siswa</option>
											<?php $qu = mysqli_query($koneksi, "select * from jenjang where status='1'");
											while ($kelas = mysqli_fetch_array($qu)) {
											?>
												<option value="<?= enkripsi($kelas['id_jenjang']) ?>"> <?= $kelas['kode'] ?>-<?= $kelas['nama_jenjang'] ?></option>
											<?php } ?>

										</select>
									</div>
								
								<div class="form-group">
									<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> CARI</button>
								</div>
							</div>
						</form>
					</div>
					
					
					
					</div>
					</div>
					<?php if (isset($_GET['id']) == '') { ?>
					
					<div class="row">
					<div class="col-md-12">
					<form id="form-kelas" method="post">
						<div class="tile">
						<div class="tile-body">
						  <div class="table-responsive">
							
								<table style="font-size: 12px" class="table table-striped table-sm table-bordered" cellspacing="0" id="sampleTable" width="100%">
									
									<thead class="bg-secondary text-white">
										<tr>
											
											<th class="text-center">
												No
											
											<th width="30%">Nama Siswa</th>
											<th>JK</th>
											<th>Tempat_Lahir</th>
											
											<?php if ($tampil['nis'] == 'Y') { ?> <th>NIS Lokal</th><?php } ?>
											<?php if ($tampil['nisn'] == 'Y') { ?> <th>No NISN</th><?php } ?>
											
											
											<th>Kelas</th>
											
											
											
										
										</tr>
									</thead>
									<tbody>
									   <?php
										$query = mysqli_query($koneksi, "select * from siswa where status='1'");
										
										$no = 0;
										while ($siswa = mysqli_fetch_array($query)) {
											$kalimat = $siswa['nis'];
											$tampil_nis    =substr($kalimat, 0, 12);
											$tgl_lahirsiswa = $siswa['tgl_lahir'];
											$kelas = fetch($koneksi, 'jenjang', ['id_jenjang' => $siswa['kelas']]);
											$no++;
										?>
											<tr>
											  
												<td><?= $no; ?></td>
												<td class="str"><?= $siswa['nama_siswa'] ?></td>
												<td><?php if ($siswa['jk'] == 'L') { ?> Laki Laki <?php } else { ?> Perempuan <?php } ?></td>
												<td>****<?= substr($siswa['tempat_lahir'],4,6) ?>**</td>
												
												<?php if ($tampil['nis'] == 'Y') { ?> <td class="str"><?= $tampil_nis; ?>***</td><?php } ?>
												<?php if ($tampil['nisn'] == 'Y') { ?> <td class="str"><?= substr($siswa['nisn'],0,5) ?>****</td><?php } ?>
												
												
												<?php if ($siswa['kelas'] == null) { ?>
														 <td> Null</td>
														<?php } else { ?>
														<td>
														<?= $kelas['kode'] ?>-<?= $kelas['nama_jenjang'] ?></i>
															</td>
														<?php } ?>
											   
												
											</tr>	
												
													
										<?php }
													?>
									</tbody></table></div>
								</div>
								</div>
								</form>
						
							</div>
						</div>

  					 <?php } else { ?>
							<?php $jenjang = fetch($koneksi, 'jenjang', ['id_jenjang' => dekripsi($_GET['id'])]) ?>
					<div class="row">
					<div class="col-md-12">
					<form id="form-kelas" method="post">
						<div class="tile">
						<div class="tile-body">
						  <div class="table-responsive">
							
								<table style="font-size: 12px" class="table table-striped table-sm table-bordered" cellspacing="0" id="sampleTable" width="100%">
									
									<thead class="bg-secondary text-white">
										<tr>
											
											<th class="text-center">
												No
											
											<th width="30%">Nama Siswa</th>
											<th>JK</th>
											<th>Tempat_Lahir</th>
											
											<?php if ($tampil['nis'] == 'Y') { ?> <th>NIS Lokal</th><?php } ?>
											<?php if ($tampil['nisn'] == 'Y') { ?> <th>No NISN</th><?php } ?>
											
											
											<th>Kelas</th>
											
											
											
										
										</tr>
									</thead>
									<tbody>
									   <?php
										$query = mysqli_query($koneksi, "select * from siswa where kelas='$jenjang[id_jenjang]'");
										
										$no = 0;
										while ($siswa = mysqli_fetch_array($query)) {
											$kalimat = $siswa['nis'];
											$tampil_nis    =substr($kalimat, 0, 15);
											$tgl_lahirsiswa = $siswa['tgl_lahir'];
											$kelas = fetch($koneksi, 'jenjang', ['id_jenjang' => $siswa['kelas']]);
											$no++;
										?>
											<tr>
											  
												<td><?= $no; ?></td>
												<td class="str"><?= $siswa['nama_siswa'] ?></td>
												<td><?php if ($siswa['jk'] == 'L') { ?> Laki Laki <?php } else { ?> Perempuan <?php } ?></td>
												<td>****<?= substr($siswa['tempat_lahir'],4,6) ?>**</td>
												
												<?php if ($tampil['nis'] == 'Y') { ?> <td class="str"><?= $tampil_nis; ?>***</td><?php } ?>
												<?php if ($tampil['nisn'] == 'Y') { ?> <td class="str"><?= substr($siswa['nisn'],0,5) ?>****</td><?php } ?>
												
												
												<?php if ($siswa['kelas'] == null) { ?>
														 <td> Null</td>
														<?php } else { ?>
														<td>
														<?= $kelas['kode'] ?>-<?= $kelas['nama_jenjang'] ?></i>
															</td>
														<?php } ?>
											   
												
											</tr>	
										<?php }
													?>
									</tbody></table></div>
								</div>
								</div>
								</form>
						
							</div>
						</div>
					 <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
    <div class="home-footer"><div class="container text-center">Copyright ©<?= date('Y') ?> <?= $setting['nama_sekolah'] ?> | <?= $create ?></div> </div>
        <script>
            var baseURL = '/';
            
        </script>
	 
        <script src="vendor/jquery-3.2.1.min.js"></script>
        <script src="vendor/jquery.form.min.js"></script>
        <script src="vendor/bootstrap.min.js"></script>
        <script src="vendor/popper.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		
		<script type="text/javascript">$('#sampleTable').DataTable();</script>
		
			<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.0/css/jquery.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.0.0/css/buttons.dataTables.min.css">
		
		<style type="text/css" class="init">
	
	</style>
	<script type="text/javascript" src="/media/js/site.js?_=e469aaf14ac009df7cbcc69a65357089"></script>
	<script type="text/javascript" src="/media/js/dynamic.php?comments-page=extensions%2Fbuttons%2Fexamples%2Finitialisation%2Fexport.html" async></script>
	<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.html5.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.print.min.js"></script>
	<script type="text/javascript" class="init">
	


$(document).ready(function() {
	$('#sampleTable').DataTable( {
		dom: 'Bfrtip',
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		]
	} );
} );



	</script>

		
		
        <!-- Vendor -->
        
        
        
        <script src="vendor/wow.min.js"></script>
        
        <!-- Assets -->
        <script src="vendor/front.min.js"></script>
        <!-- Assets -->
	<script>
    $('#form-login').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'user/crud_web.php?pg=login',
            data: $(this).serialize(),
            beforeSend: function() {
                $('#btnsimpan').prop('disabled', true);
            },
            success: function(data) {
                var json = $.parseJSON(data);
                $('#btnsimpan').prop('disabled', false);
                if (json.pesan == 'ok') {
                    iziToast.success({
                        title: 'Mantap!',
                        message: 'Login Berhasil',
                        position: 'topRight'
                    });
                    setTimeout(function() {
                        window.location.href = "user";
                    }, 2000);

                } else {
                    iziToast.error({
                        title: 'Maaf!',
                        message: json.pesan,
                        position: 'topCenter'
                    });
                }
                //$('#bodyreset').load(location.href + ' #bodyreset');
            }
        });
        return false;
    });
	
    
    
</script>

<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		


</body>

</html>