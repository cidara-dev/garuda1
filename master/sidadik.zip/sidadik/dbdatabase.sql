-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 08 Sep 2021 pada 08.25
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `share_dbdatabase`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `histori`
--

CREATE TABLE `histori` (
  `id` int(11) NOT NULL,
  `id_permohonan` varchar(30) NOT NULL,
  `nik` int(30) NOT NULL,
  `status` int(1) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `histori`
--

INSERT INTO `histori` (`id`, `id_permohonan`, `nik`, `status`, `tanggal`, `keterangan`) VALUES
(1, '201907070001', 123, 1, '2019-07-07 14:57:31', 'Silahkan datang ke desa/kelurahan setempat untuk pengumpulan berkas persyaratan permohonan  dan konfirmasi'),
(2, '201907070001', 0, 2, '2019-07-07 21:26:33', 'pemberkasan sedang kami proses silahkan untuk menunggu'),
(4, '202004040001', 12, 1, '2020-04-04 17:25:29', 'Silahkan datang ke desa/kelurahan setempat untuk pengumpulan berkas persyaratan permohonan  dan konfirmasi'),
(5, '202004040002', 12, 1, '2020-04-04 17:25:55', 'Permohonan sudah berhasil masuk, mohon untuk menunggu proses pengecekan data');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis`
--

CREATE TABLE `jenis` (
  `id_jenis` varchar(50) NOT NULL,
  `nama_jenis` varchar(50) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenis`
--

INSERT INTO `jenis` (`id_jenis`, `nama_jenis`, `status`) VALUES
('PD', 'Pindahan', 1),
('SB', 'Siswa Baru', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenjang`
--

CREATE TABLE `jenjang` (
  `id_jenjang` int(11) NOT NULL,
  `kode` int(11) NOT NULL,
  `nama_jenjang` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `wali` int(11) NOT NULL,
  `jumlah_siswa` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenjang`
--

INSERT INTO `jenjang` (`id_jenjang`, `kode`, `nama_jenjang`, `status`, `wali`, `jumlah_siswa`) VALUES
(3, 10, 'IPS', 1, 0, ''),
(4, 11, 'IPS', 1, 0, ''),
(6, 12, 'IPS', 1, 0, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE `jurusan` (
  `id_jurusan` varchar(50) NOT NULL,
  `nama_jurusan` varchar(100) DEFAULT NULL,
  `kuota` int(10) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`id_jurusan`, `nama_jurusan`, `kuota`, `status`) VALUES
('IPA', 'IPA', 22, 1),
('IPS', 'IPS', 2, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id`, `nama`, `status`) VALUES
(2, 'BERITA', 1),
(3, 'Artikel', 1),
(4, 'Teknologi', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kontak`
--

CREATE TABLE `kontak` (
  `id_kontak` int(11) NOT NULL,
  `nama_kontak` varchar(50) DEFAULT NULL,
  `no_kontak` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kontak`
--

INSERT INTO `kontak` (`id_kontak`, `nama_kontak`, `no_kontak`, `status`) VALUES
(1, 'Nasrulloh', '081210654096', 1),
(2, 'Tugiman', '081282656407', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengumuman`
--

CREATE TABLE `pengumuman` (
  `id_pengumuman` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `pengumuman` text DEFAULT NULL,
  `tgl` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `jenis` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengumuman`
--

INSERT INTO `pengumuman` (`id_pengumuman`, `id_user`, `judul`, `pengumuman`, `tgl`, `jenis`) VALUES
(9, 85, 'Info PPDB Online 2021', '<h5 style=\"mso-margin-bottom-alt:auto;line-height:normal\"><p class=\"MsoNormal\" style=\"mso-margin-bottom-alt:auto;line-height:normal\"><span style=\"font-size: 10pt; font-family: Arial, sans-serif;\">Assalamualikum\r\nwr wb..<o:p></o:p></span></p><p class=\"MsoNormal\" style=\"mso-margin-bottom-alt:auto;line-height:normal\"><span style=\"font-size: 10pt; font-family: Arial, sans-serif;\">Untuk\r\nPendaftar Gelombang 1 akan di tutup Tanggal 30 Mei 2021. Jadwal Daftar ulang\r\ntanggal Gelombnag 1 Tanggal 01 Juni Sampai Dengan 07 Juni 2021.<o:p></o:p></span></p><p class=\"MsoNormal\" style=\"mso-margin-bottom-alt:auto;line-height:normal\"><span style=\"font-size: 10pt; font-family: Arial, sans-serif;\">Berkas\r\nyang harus dibawa ke sekolah saat daftar Ulang diantaranya<o:p></o:p></span></p><ol start=\"1\" type=\"1\">\r\n <li class=\"MsoNormal\" style=\"line-height: normal;\"><span style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;\r\n     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US\">Fhotocopy\r\n     Kartu Keluarga<o:p></o:p></span></li>\r\n <li class=\"MsoNormal\" style=\"line-height: normal;\"><span style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;\r\n     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US\">Photocopy\r\n     Akta Kelahiran<o:p></o:p></span></li>\r\n <li class=\"MsoNormal\" style=\"line-height: normal;\"><span style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;\r\n     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US\">Photocopy\r\n     Raport Terakhir<o:p></o:p></span></li>\r\n <li class=\"MsoNormal\" style=\"line-height: normal;\"><span style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;\r\n     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US\">Photocopy\r\n     KIP,PKH (Jika ada)<o:p></o:p></span></li>\r\n <li class=\"MsoNormal\" style=\"line-height: normal;\"><span style=\"font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;\r\n     mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US\">Photocopy\r\n     Surat Keterangan Lulus atau Ijazah (Jika sudah ada)<o:p></o:p></span></li>\r\n</ol><p class=\"MsoNormal\" style=\"mso-margin-bottom-alt:auto;line-height:normal\">\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p><p class=\"MsoNormal\" style=\"mso-margin-bottom-alt:auto;line-height:normal\"><span style=\"font-size: 10pt; font-family: Arial, sans-serif;\">Demikian\r\nkami infokan untuk sama sama di maklumi.<o:p></o:p></span></p></h5><p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p>', '2021-08-29 21:29:25', 1),
(10, 85, 'tes', '<p>d</p>', '2021-09-03 23:03:46', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `setting`
--

CREATE TABLE `setting` (
  `id_setting` int(1) NOT NULL,
  `nama_sekolah` varchar(100) NOT NULL,
  `jenjang` int(11) NOT NULL,
  `nsm` varchar(30) NOT NULL,
  `npsn` varchar(30) DEFAULT NULL,
  `status` text NOT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `kota` varchar(30) DEFAULT NULL,
  `provinsi` varchar(30) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `favicon` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `klikchat` text DEFAULT NULL,
  `livechat` text DEFAULT NULL,
  `nolivechat` varchar(50) DEFAULT NULL,
  `infobayar` text DEFAULT NULL,
  `syarat` text DEFAULT NULL,
  `kab` text NOT NULL,
  `kec` text NOT NULL,
  `web` text NOT NULL,
  `kepala` text NOT NULL,
  `nip` text NOT NULL,
  `ppdb` text DEFAULT NULL,
  `kop` varchar(50) NOT NULL,
  `logo_ppdb` varchar(100) NOT NULL,
  `tgl_pengumuman` date NOT NULL,
  `tgl_tutup` date NOT NULL,
  `token` text CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `tema` text NOT NULL,
  `password` text NOT NULL,
  `login` int(1) NOT NULL,
  `_kop` int(1) NOT NULL,
  `lembaga` varchar(128) NOT NULL,
  `template` varchar(128) NOT NULL,
  `ttd` varchar(128) NOT NULL,
  `stempel` varchar(128) NOT NULL,
  `tgl_cetak` date NOT NULL,
  `header` text NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `setting`
--

INSERT INTO `setting` (`id_setting`, `nama_sekolah`, `jenjang`, `nsm`, `npsn`, `status`, `alamat`, `kota`, `provinsi`, `logo`, `favicon`, `email`, `no_telp`, `klikchat`, `livechat`, `nolivechat`, `infobayar`, `syarat`, `kab`, `kec`, `web`, `kepala`, `nip`, `ppdb`, `kop`, `logo_ppdb`, `tgl_pengumuman`, `tgl_tutup`, `token`, `tema`, `password`, `login`, `_kop`, `lembaga`, `template`, `ttd`, `stempel`, `tgl_cetak`, `header`, `isi`) VALUES
(1, 'MA NURUL MUJAHIDAH NW TANJUNG SELOR', 1, '131265010003', '69977331', 'Swasta', 'Jln Salak rt 06 rw 01 desa Gunung Sari', '', 'Kalimantan Utara', 'assets/img/logo/logo.png', NULL, 'ma52nwkaltara@gmail.com', '087854743264', 'Assalamualaikum ', 'Assalamualaikum Wr Wb', '087854743264', 'Untuk Info Pembayaran Bisa di Tulis disini melalui Fitur Setting PPDB', '<p><br></p><ol><li>Surat Keterangan Lulus</li><li>Akta Kelahiran</li><li>Kartu Keluarga</li></ol>', 'Bulungan', 'Tanjung Selor', 'ma.nwkaltara.web.id', 'SOPIAN HADI,S.Kom.I', '-', '0', 'assets/img/kop/kop389.png', 'assets/img/logo/logo_ppdb.png', '2021-04-07', '2021-12-10', '0', 'tema6-style.css', '$2y$10$XGmY0sw.MU5wN0nPnYVMt.N/4w6sG1L1hTDGSThfuA9fDVzybi7.W', 1, 0, 'YAYASAN PENDIDIKAN SYAIKH ZAINUDDIN NW KALTARA', 'assets/img/template/template415.png', 'assets/img/template/ttd536.png', 'assets/img/template/stempel484.png', '2020-07-14', 'PENGUMUMAN', '<ol><li style=\"text-align: justify; \"><b>Kartu Pelajar </b>ini merupakan kartu identitas resmi untuk siswa di MA&nbsp; Nurul Mujahidah NW Tanjung Selor</li><li style=\"text-align: justify;\">Kartu Pelajar ini berlaku selama Tercatat menjadi siswa/siswi aktif di MA Nurul Mujahidah NW Tanjung Selor</li><li style=\"text-align: justify;\">Status Kartu pelajar dapat di cek melalui laman Website resmi kami atau melalui scan barcode</li></ol>');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int(4) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `no_daftar` varchar(20) NOT NULL,
  `kelas` varchar(5) NOT NULL,
  `nama_siswa` varchar(256) NOT NULL,
  `nisn` varchar(10) NOT NULL,
  `warga_siswa` varchar(256) DEFAULT NULL,
  `nik` varchar(30) DEFAULT NULL,
  `tempat_lahir` varchar(256) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `jk` varchar(1) DEFAULT NULL,
  `anak_ke` int(2) DEFAULT NULL,
  `saudara` int(11) DEFAULT NULL,
  `agama` varchar(256) DEFAULT NULL,
  `cita` varchar(256) DEFAULT NULL,
  `no_hp` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `hobi` varchar(256) DEFAULT NULL,
  `status_tinggal_siswa` varchar(256) DEFAULT NULL,
  `prov` varchar(256) DEFAULT NULL,
  `kab` varchar(256) DEFAULT NULL,
  `kec` varchar(256) DEFAULT NULL,
  `desa` varchar(256) DEFAULT NULL,
  `alamat_siswa` varchar(256) DEFAULT NULL,
  `kordinat` varchar(256) DEFAULT NULL,
  `kodepos_siswa` varchar(6) DEFAULT NULL,
  `transportasi` varchar(256) DEFAULT NULL,
  `jarak` varchar(256) DEFAULT NULL,
  `waktu` varchar(256) DEFAULT NULL,
  `biaya_sekolah` varchar(256) DEFAULT NULL,
  `keb_khusus` varchar(256) DEFAULT NULL,
  `keb_disabilitas` varchar(256) DEFAULT NULL,
  `tk` varchar(1) DEFAULT NULL,
  `paud` varchar(1) DEFAULT NULL,
  `hepatitis` varchar(1) DEFAULT NULL,
  `polio` varchar(1) DEFAULT NULL,
  `bcg` varchar(1) DEFAULT NULL,
  `campak` varchar(1) DEFAULT NULL,
  `dpt` varchar(1) DEFAULT NULL,
  `covid` varchar(1) DEFAULT NULL,
  `no_kip` varchar(256) DEFAULT NULL,
  `no_kks` varchar(256) DEFAULT NULL,
  `no_pkh` varchar(256) DEFAULT NULL,
  `no_kk` varchar(16) DEFAULT NULL,
  `kepala_keluarga` varchar(256) DEFAULT NULL,
  `nama_ayah` varchar(256) DEFAULT NULL,
  `status_ayah` varchar(256) DEFAULT NULL,
  `warga_ayah` varchar(256) DEFAULT NULL,
  `nik_ayah` varchar(16) DEFAULT NULL,
  `tempat_lahir_ayah` varchar(256) DEFAULT NULL,
  `tgl_lahir_ayah` date DEFAULT NULL,
  `pendidikan_ayah` varchar(256) DEFAULT NULL,
  `pekerjaan_ayah` varchar(256) DEFAULT NULL,
  `penghasilan_ayah` varchar(256) DEFAULT NULL,
  `no_hp_ayah` varchar(256) DEFAULT NULL,
  `domisili_ayah` varchar(256) DEFAULT NULL,
  `status_tmp_tinggal_ayah` varchar(256) DEFAULT NULL,
  `prov_ayah` varchar(256) DEFAULT NULL,
  `kab_ayah` varchar(256) DEFAULT NULL,
  `kec_ayah` varchar(256) DEFAULT NULL,
  `desa_ayah` varchar(256) DEFAULT NULL,
  `alamat_ayah` varchar(256) DEFAULT NULL,
  `kodepos_ayah` varchar(6) DEFAULT NULL,
  `nama_ibu` varchar(256) DEFAULT NULL,
  `status_ibu` varchar(256) DEFAULT NULL,
  `warga_ibu` varchar(256) DEFAULT NULL,
  `nik_ibu` varchar(256) DEFAULT NULL,
  `tempat_lahir_ibu` varchar(256) DEFAULT NULL,
  `tgl_lahir_ibu` date DEFAULT NULL,
  `pendidikan_ibu` varchar(256) DEFAULT NULL,
  `pekerjaan_ibu` varchar(256) DEFAULT NULL,
  `penghasilan_ibu` varchar(256) DEFAULT NULL,
  `no_hp_ibu` varchar(256) DEFAULT NULL,
  `status_tinggal_ibu` varchar(256) DEFAULT NULL,
  `domisili_ibu` varchar(128) DEFAULT NULL,
  `status_tmp_tinggal_ibu` varchar(256) DEFAULT NULL,
  `prov_ibu` varchar(256) DEFAULT NULL,
  `kab_ibu` varchar(256) DEFAULT NULL,
  `kec_ibu` varchar(256) DEFAULT NULL,
  `desa_ibu` varchar(256) DEFAULT NULL,
  `alamat_ibu` varchar(256) DEFAULT NULL,
  `kodepos_ibu` varchar(6) DEFAULT NULL,
  `status_wali` varchar(256) DEFAULT NULL,
  `nama_wali` varchar(256) DEFAULT NULL,
  `warga_wali` varchar(256) DEFAULT NULL,
  `nik_wali` varchar(16) DEFAULT NULL,
  `tempat_lahir_wali` varchar(256) DEFAULT NULL,
  `tgl_lahir_wali` date DEFAULT NULL,
  `pendidikan_wali` varchar(256) DEFAULT NULL,
  `pekerjaan_wali` varchar(256) DEFAULT NULL,
  `penghasilan_wali` varchar(256) DEFAULT NULL,
  `no_hp_wali` varchar(16) DEFAULT NULL,
  `domisili_wali` varchar(256) DEFAULT NULL,
  `prov_wali` varchar(256) DEFAULT NULL,
  `kab_wali` varchar(256) DEFAULT NULL,
  `kec_wali` varchar(256) DEFAULT NULL,
  `desa_wali` varchar(256) DEFAULT NULL,
  `alamat_wali` varchar(256) DEFAULT NULL,
  `kodepos_wali` varchar(256) DEFAULT NULL,
  `foto` varchar(128) NOT NULL,
  `jurusan` varchar(256) DEFAULT NULL,
  `file_kip` varchar(256) DEFAULT NULL,
  `file_kk` varchar(256) DEFAULT NULL,
  `file_ijazah` varchar(256) DEFAULT NULL,
  `file_akte` varchar(256) DEFAULT NULL,
  `file_shun` varchar(256) DEFAULT NULL,
  `tgl_mutasi` date DEFAULT NULL,
  `surat_masuk` text NOT NULL,
  `alasan_mutasi` varchar(100) DEFAULT NULL,
  `asal_sekolah` text NOT NULL,
  `sekolah_mutasi` varchar(255) DEFAULT NULL,
  `level` varchar(10) DEFAULT NULL,
  `aktif` int(1) DEFAULT 0,
  `status` int(1) DEFAULT 0,
  `tgl_siswa` date DEFAULT NULL,
  `online` int(1) DEFAULT 0,
  `password` text DEFAULT NULL,
  `jenis` int(11) DEFAULT NULL,
  `kelasmutasi` text NOT NULL,
  `konfirmasi` int(11) NOT NULL,
  `tahun_lulus` text DEFAULT NULL,
  `no_ijazahalumni` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nis`, `no_daftar`, `kelas`, `nama_siswa`, `nisn`, `warga_siswa`, `nik`, `tempat_lahir`, `tgl_lahir`, `jk`, `anak_ke`, `saudara`, `agama`, `cita`, `no_hp`, `email`, `hobi`, `status_tinggal_siswa`, `prov`, `kab`, `kec`, `desa`, `alamat_siswa`, `kordinat`, `kodepos_siswa`, `transportasi`, `jarak`, `waktu`, `biaya_sekolah`, `keb_khusus`, `keb_disabilitas`, `tk`, `paud`, `hepatitis`, `polio`, `bcg`, `campak`, `dpt`, `covid`, `no_kip`, `no_kks`, `no_pkh`, `no_kk`, `kepala_keluarga`, `nama_ayah`, `status_ayah`, `warga_ayah`, `nik_ayah`, `tempat_lahir_ayah`, `tgl_lahir_ayah`, `pendidikan_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `no_hp_ayah`, `domisili_ayah`, `status_tmp_tinggal_ayah`, `prov_ayah`, `kab_ayah`, `kec_ayah`, `desa_ayah`, `alamat_ayah`, `kodepos_ayah`, `nama_ibu`, `status_ibu`, `warga_ibu`, `nik_ibu`, `tempat_lahir_ibu`, `tgl_lahir_ibu`, `pendidikan_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `no_hp_ibu`, `status_tinggal_ibu`, `domisili_ibu`, `status_tmp_tinggal_ibu`, `prov_ibu`, `kab_ibu`, `kec_ibu`, `desa_ibu`, `alamat_ibu`, `kodepos_ibu`, `status_wali`, `nama_wali`, `warga_wali`, `nik_wali`, `tempat_lahir_wali`, `tgl_lahir_wali`, `pendidikan_wali`, `pekerjaan_wali`, `penghasilan_wali`, `no_hp_wali`, `domisili_wali`, `prov_wali`, `kab_wali`, `kec_wali`, `desa_wali`, `alamat_wali`, `kodepos_wali`, `foto`, `jurusan`, `file_kip`, `file_kk`, `file_ijazah`, `file_akte`, `file_shun`, `tgl_mutasi`, `surat_masuk`, `alasan_mutasi`, `asal_sekolah`, `sekolah_mutasi`, `level`, `aktif`, `status`, `tgl_siswa`, `online`, `password`, `jenis`, `kelasmutasi`, `konfirmasi`, `tahun_lulus`, `no_ijazahalumni`) VALUES
(17, '131265010003190024', '', '', 'AHMAD SALMAN', '0021818665', '', '6404032408020001', 'Karang Agung', '2002-08-24', 'L', 0, 0, 'Islam', '', '', '', '', '', 'Kalimantan Utara', '', '', '', 'Desa Ruhui Rahayu', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Tasehan', 'Tasehan', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', 'Bunimah', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-07-24', '008-S.Ket/MA.NM/NW/VII/2021', 'Lainnya', '', 'MAN Bulungan', NULL, 0, 2, NULL, 0, NULL, NULL, '6', 0, NULL, NULL),
(20, '131265010003190028', '', '', 'M.ALI SAPUTRA', '0042981588', 'WNI', '', 'Gunung Sari', '2004-05-15', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', 'Antara 5-10 km', '10-19 menit', 'Orangtua', 'Tidak ada', 'Tidak ada', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '', '', '', '', 'Laholong Leco', 'Laholong Leco', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'assets/upload/foto_siswa/siswa245.png', NULL, NULL, NULL, NULL, NULL, NULL, '2021-08-28', '-', '-', '', 'Lainnya', NULL, 0, 2, NULL, 0, NULL, NULL, '6', 0, NULL, NULL),
(22, '131265010003190031', '', '', 'NAZWA BANSIR', '0048246565', '', '6404055708040004', 'Tanjung Selor', '2004-04-16', 'P', 0, 0, 'Islam', '', '', '', '', '', 'Kalimantan Utara', 'Bulungan', 'Tanjung Selor', 'Tanjung Selor Hulu', 'Jalan Jendral Sudirman', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '6404052802080012', 'Idham Bansir', 'Idham Bansir', '', '', '6404052802660002', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', 'Jainun Ahmad Bansir', '', '', '6404056810790004', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2020-06-10', '002-S.Ket/MA.NM/NW/VI/2020', 'Lainnya', '', 'MAN Bulungan', NULL, 0, 2, NULL, 0, NULL, NULL, '4', 0, NULL, NULL),
(23, '131265010003190033', '', '', 'NORMA AYU MAWAR', '0045516558', '', '6404036301040002', 'Tanjung Palas', '2004-03-07', 'P', 0, 0, 'Islam', '', '', '', '', '', '', '', '', '', 'Tanjung Selor', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Buyung', 'Buyung', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', 'Nurhayati Ningsih', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2020-07-02', '003-S.Ket/MA.NM/NW/VII/2020', 'Lainnya', '', 'MAN Bulungan', NULL, 0, 2, NULL, 0, NULL, NULL, '3', 0, NULL, NULL),
(36, '131265010003200048', '', '', 'SUSI HERAWATI', '0048580491', '', '6404045407040002', 'Mangkupadi', '2004-07-14', 'P', 0, 0, 'Islam', '', '', '', '', '', '', '', '', '', 'Kampung Baru, desa Mangkupadi', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-07-24', '007-S.Ket/MA.NM/NW/VII/2021', 'Lainnya', '', 'MAN Bulungan', NULL, 0, 2, NULL, 0, NULL, NULL, '4', 0, NULL, NULL),
(105, '', 'PPDB2021005', '', 'Ahmad Syafii', '12432', NULL, NULL, 'BULUNGAN', '2021-08-08', NULL, NULL, NULL, NULL, NULL, '0987667888', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 'Asal sekolah saya', NULL, NULL, 0, 0, NULL, 0, '1', 1, '', 0, NULL, NULL),
(106, '', 'PPDB2021006', '', 'Ajhjd Hjdhk', '0987654', NULL, NULL, 'Tanjung Selor', '2021-08-02', NULL, NULL, NULL, NULL, NULL, '0987654', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 'Asal sekolah saya', NULL, NULL, 0, 0, NULL, 0, '1', 1, '', 0, NULL, NULL),
(107, '', 'PPDB2021007', '', 'Ggfg', '79686786', NULL, NULL, 'FGHFGH', '2021-08-09', NULL, NULL, NULL, NULL, NULL, '6756657', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 'Asal Sekolah', NULL, NULL, 0, 0, NULL, 0, '1', 1, '', 0, NULL, NULL),
(117, '', 'PPDB2021008', '', 'Ewrwr', '214545', NULL, NULL, 'WER', '2021-08-10', NULL, NULL, NULL, NULL, NULL, '082342398998', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 'admin', NULL, NULL, 0, 0, NULL, 0, 'admin', 1, '', 0, NULL, NULL),
(118, '', 'PPDB2021009', '', 'PINDAH MASUK', '12346666', NULL, NULL, 'Bandung', '2021-08-12', 'L', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 'MA Nurul Mujahidah NW', NULL, NULL, 0, 0, NULL, 0, NULL, 1, '', 0, NULL, NULL),
(119, '', 'PPDB2021010', '', 'Gbfgdgs', '575786', NULL, NULL, 'Tanjung Selor', '2021-08-17', NULL, NULL, NULL, NULL, NULL, '082342398998', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 'Asal sekolah saya', NULL, NULL, 0, 0, NULL, 0, 'admin', 1, '', 0, NULL, NULL),
(178, '131265010003190029', '', '3', 'MUHAMAD JAMIL', '0044451503', '', '', 'Ruhui Rahayu', '2004-04-20', 'L', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '77212', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'assets/upload/foto_siswa/siswa433.png', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-07', '006.MA/NW/III/2021', 'Mengikuti Orang Tua', '', 'MAN Bulungan', NULL, 0, 1, NULL, 0, NULL, NULL, '3', 0, '2021', ''),
(182, '131265010003190039', '', '3', 'ZAENUR ARI RAHMAN', '0044451507', NULL, '', 'Aik Bukak', '2004-04-24', 'L', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-07', '00.8MA/NW/III/2021', 'Mengikuti Orang Tua', '', 'MAN Bulungan', NULL, 0, 1, NULL, 0, NULL, NULL, '3', 0, '2022', ''),
(187, '131265010003190029', '', '', 'MUHAMAD JAMIL', '0044451503', NULL, '', 'Ruhui Rahayu', '2004-04-20', 'L', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-07', '006.MA/NW/III/2021', 'Mengikuti Orang Tua', '', 'MAN Bulungan', NULL, 0, 2, NULL, 0, NULL, NULL, '3', 0, '2024', ''),
(191, '131265010003190039', '', '3', 'ZAENUR ARI RAHMAN', '0044451507', NULL, '', 'Aik Bukak', '2004-04-24', 'L', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-07', '00.8MA/NW/III/2021', 'Mengikuti Orang Tua', '', 'MAN Bulungan', NULL, 0, 1, NULL, 0, NULL, NULL, '3', 0, '2028', ''),
(192, '', 'PPDB2021011', '', 'Pindah Masuk', '0043331469', NULL, NULL, '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, '082342398998', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'IPA', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 'MA Setia Peradaban', NULL, NULL, 0, 0, NULL, 0, '1', 0, '', 0, NULL, NULL),
(193, '', 'PPDB2021012', '', 'Mtsn1 Alor 2', '0023084267', NULL, NULL, '', '0000-00-00', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 0, NULL, 0, '', 0, '', 0, NULL, NULL),
(194, '', 'PPDB2021013', '', 'Nama Saya', '1234512', NULL, NULL, 'BALANGSADE', '2021-09-08', NULL, NULL, NULL, NULL, NULL, '09767868789', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'IPS', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '1', NULL, NULL, 0, 0, NULL, 0, '1', 1, '', 0, NULL, NULL),
(208, '131265010003190029', '', '3', 'MUHAMAD JAMIL', '0044451503', 'WNI', '', 'Ruhui Rahayu', '2004-04-20', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-07', '006.MA/NW/III/2021', 'Mengikuti Orang Tua', '', 'MAN Bulungan', NULL, 0, 1, NULL, 0, NULL, NULL, '3', 0, NULL, NULL),
(210, '131265010003190037', '', '3', 'SUKRON ZAILANI', '0044451505', 'WNI', '', 'Gunung Sari', '2004-04-22', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 1, NULL, 0, NULL, NULL, '', 0, NULL, NULL),
(211, '131265010003190038', '', '3', 'ULFA EDA', '0044451506', 'WNI', '', 'Tarakan', '2004-04-23', 'P', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', 'Klaimantan Utara', 'Bulungan', 'Tanjung Palas Timur', 'Sajau Hilir', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 1, NULL, 0, NULL, NULL, '', 0, NULL, NULL),
(212, '131265010003190039', '', '3', 'ZAENUR ARI RAHMAN', '0044451507', 'WNI', '', 'Aik Bukak', '2004-04-24', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-07', '00.8MA/NW/III/2021', 'Mengikuti Orang Tua', '', 'MAN Bulungan', NULL, 0, 1, NULL, 0, NULL, NULL, '3', 0, NULL, NULL),
(213, '131265010003190023', '', '3', 'ABDUL LATIF', '0044451499', 'WNI', '', 'Makajang', '2004-04-16', 'L', 1, 2, 'Islam', 'PNS', '', '', 'Olahraga', 'Tinggal di asrama pesantren', 'KALIMANTAN UTARA', 'BULUNGAN', 'TANJUNG SELOR', 'GUNUNG SARI', 'JALAN SALAK RT 06 RW 01 DESA GUNUNG SARI', '', '', 'Jalan kaki', 'Antara 5-10 km', '10-19 menit', 'Orangtua', 'Tidak ada', 'Tidak ada', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '77371', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 1, NULL, 0, NULL, NULL, '', 0, NULL, NULL),
(214, '131265010003190026', '', '3', 'BADARIANSYAH', '0044451500', 'WNI', '', 'Tanjung Palas', '2004-04-17', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', 'Antara 5-10 km', '10-19 menit', 'Orangtua', 'Tidak ada', 'Tidak ada', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 1, NULL, 0, NULL, NULL, '', 0, NULL, NULL),
(215, '131265010003190027', '', '', 'GINA NOVITA SARI', '0044451501', 'WNI', '', 'Gunung Sari', '2004-04-18', 'P', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', 'Kalimantan Utara', 'Bulungan', 'Tanjung Selor', 'Gunung Sari', '', '', '', '', 'Antara 5-10 km', '10-19 menit', 'Orangtua', 'Tidak ada', 'Tidak ada', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 3, NULL, 0, NULL, 0, '', 0, '2020', NULL),
(216, '131265010003190028', '', '', 'M.ALI SAPUTRA', '0044451502', 'WNI', '', 'Gunung Sari', '2004-04-19', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', 'Antara 5-10 km', '10-19 menit', 'Orangtua', 'Tidak ada', 'Tidak ada', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 1, NULL, 0, NULL, NULL, '', 0, NULL, NULL),
(217, '131265010003190029', '', '', 'MUHAMAD JAMIL', '0044451503', 'WNI', '', 'Ruhui Rahayu', '2004-04-20', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-07', '006.MA/NW/III/2021', 'Mengikuti Orang Tua', '', 'MAN Bulungan', NULL, 0, 3, NULL, 0, NULL, 0, '3', 0, '2021', NULL),
(218, '131265010003190036', '', '', 'SITI SOFIYATI MAULA', '0044451504', 'WNI', '', 'Peringga Baya', '2004-04-21', 'P', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', 'NTB', 'Lombok Timur', 'Montong Gading', 'Pringga Jurang Utara', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', 'assets/upload/foto_siswa/siswa353.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 3, NULL, 0, NULL, 0, '', 0, '2021', NULL),
(219, '131265010003190037', '', '', 'SUKRON ZAILANI', '0044451505', 'WNI', '', 'Gunung Sari', '2004-04-22', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 1, NULL, 0, NULL, NULL, '', 0, NULL, NULL),
(220, '131265010003190038', '', '', 'ULFA EDA', '0044451506', 'WNI', '', 'Tarakan', '2004-04-23', 'P', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', 'Klaimantan Utara', 'Bulungan', 'Tanjung Palas Timur', 'Sajau Hilir', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '', NULL, NULL, 0, 1, NULL, 0, NULL, NULL, '', 0, NULL, NULL),
(221, '131265010003190039', '', '', 'ZAENUR ARI RAHMAN', '0044451507', 'WNI', '', 'Aik Bukak', '2004-04-24', 'L', 0, 0, 'Islam', '', '', '', '', 'Tinggal di asrama pesantren', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-07', '00.8MA/NW/III/2021', 'Mengikuti Orang Tua', '', 'MAN Bulungan', NULL, 0, 1, NULL, 0, NULL, NULL, '3', 0, NULL, NULL),
(222, '', '', '4', 'RIYUN ARYUNI', '0023084267', NULL, NULL, 'RANDUBANGKOL', '2021-09-08', 'P', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Jalan Sabanar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default.png', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-08', '003.MA/NW/VIII/2021', NULL, 'MA Nurul Mujahidah NW', NULL, NULL, 0, 1, NULL, 0, NULL, 2, '', 0, NULL, NULL),
(223, '', '', '4', 'MTSN1 ALOR 2', '0043331469', NULL, NULL, 'BERAU', '2021-09-15', 'P', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'JLSALAK RT 06 RW 01 DESA GUNUNG SARI, -', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default.png', NULL, NULL, NULL, NULL, NULL, NULL, '2021-09-08', '008-S.Ket/MA.NM/NW/VII/2021', NULL, 'MA ahmada', NULL, NULL, 0, 1, NULL, 0, NULL, 2, '', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tampil`
--

CREATE TABLE `tampil` (
  `id` int(1) NOT NULL,
  `nisn` text NOT NULL,
  `nis` varchar(11) NOT NULL,
  `nik` text NOT NULL,
  `no_kk` text NOT NULL,
  `no_kip` text NOT NULL,
  `no_hp` text NOT NULL,
  `kewarganegaraan` text NOT NULL,
  `anak_ke` text NOT NULL,
  `saudara` text NOT NULL,
  `status_tinggal` text NOT NULL,
  `nama_ayah` text NOT NULL,
  `status_ayah` text NOT NULL,
  `nik_ayah` text NOT NULL,
  `pendidikan_ayah` text NOT NULL,
  `nama_ibu` text NOT NULL,
  `status_ibu` text NOT NULL,
  `nik_ibu` text NOT NULL,
  `pendidikan_ibu` text NOT NULL,
  `penghasilan_ayah` text NOT NULL,
  `penghasilan_ibu` text NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tampil`
--

INSERT INTO `tampil` (`id`, `nisn`, `nis`, `nik`, `no_kk`, `no_kip`, `no_hp`, `kewarganegaraan`, `anak_ke`, `saudara`, `status_tinggal`, `nama_ayah`, `status_ayah`, `nik_ayah`, `pendidikan_ayah`, `nama_ibu`, `status_ibu`, `nik_ibu`, `pendidikan_ibu`, `penghasilan_ayah`, `penghasilan_ibu`, `alamat`) VALUES
(1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(128) NOT NULL,
  `level` varchar(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` text NOT NULL,
  `status` int(1) NOT NULL,
  `foto` int(11) NOT NULL,
  `mapel` text NOT NULL,
  `nuptk` text NOT NULL,
  `jenkel` varchar(20) NOT NULL,
  `tempat_lahir` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `tmt` year(4) NOT NULL,
  `no_sk` text NOT NULL,
  `jenis` text NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `nik` int(11) NOT NULL,
  `akses` varchar(128) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `pendidikan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `level`, `username`, `password`, `status`, `foto`, `mapel`, `nuptk`, `jenkel`, `tempat_lahir`, `tgl_lahir`, `tmt`, `no_sk`, `jenis`, `no_hp`, `nik`, `akses`, `kelas`, `pendidikan`) VALUES
(97, 'H. SUKRI IRWAN QH.,S.Pd.I', 'gtk', '2432455', '', 1, 0, '', '', '', 'Bandung', '0024-03-21', 0000, '', '', '', 0, '', '', 'SD/Sederajat'),
(99, 'H. SUKRI IRWAN QH.,S.Pd.I', 'gtk', '50202796178001', '', 1, 0, '', '', '', 'Bandung', '2021-09-14', 0000, '', '', '', 0, '', '', 'SMP/Sederajat'),
(92, 'H. SUKRI IRWAN QH.,S.Pd.I', 'gtk', '69977327', '$2y$10$UwR9k6mPBeignX/D3skX5evXNPbRW7ZLVNN24Lb/msh2yap61UjWG', 1, 0, '', '', '', '', '0000-00-00', 0000, '', '', '', 0, '', '', ''),
(101, 'IPS', 'gtk', '69977327777', '', 1, 0, '', '', '', 'Bandung', '2021-09-15', 0000, '', '', '', 0, '', '', 'D4/S1'),
(85, 'Admin', '', 'admin', '$2y$10$.DmNujKCclksJZV6CvwxquSQX6dGDT9T/wLCX4pMb2wrzIMAh/.2a', 2, 0, '', '', '', '', '0000-00-00', 0000, '', '', '', 0, 'admin', '', ''),
(75, 'NASRULLOH', '', 'alfakir.nasrulloh@gmail.com', '$2y$10$DdhtgWkO3adaXxwMkRtWAeWNzWNNvLfyG22Z7NTVp0Aa3DGd1dgrK', 2, 0, '', '', '', '', '0000-00-00', 0000, '', '', '', 0, 'admin', '', ''),
(95, 'dwadef', 'gtk', 'fer', '$2y$10$gXKTkXfYnvsj5hCUZCgvp.KMAGOdHQOUnj03TLGx8J/rKcnYItL/a', 1, 0, '', '', '', '', '0000-00-00', 0000, '', '', '', 0, '', '', ''),
(102, 'Nasrulloh', '', 'panitiappdb1', '$2y$10$zZFOUspPz53MSdtYxoWiLOQrjUPcfONflJf9HHgfLhCovPe6aWqtC', 2, 0, '', '', '', '', '0000-00-00', 0000, '', '', '', 0, 'ppdb', '', '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `histori`
--
ALTER TABLE `histori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jenis`
--
ALTER TABLE `jenis`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indeks untuk tabel `jenjang`
--
ALTER TABLE `jenjang`
  ADD PRIMARY KEY (`id_jenjang`);

--
-- Indeks untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kontak`
--
ALTER TABLE `kontak`
  ADD PRIMARY KEY (`id_kontak`);

--
-- Indeks untuk tabel `pengumuman`
--
ALTER TABLE `pengumuman`
  ADD PRIMARY KEY (`id_pengumuman`);

--
-- Indeks untuk tabel `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id_setting`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`) USING BTREE,
  ADD KEY `nisn_2` (`nisn`) USING BTREE;

--
-- Indeks untuk tabel `tampil`
--
ALTER TABLE `tampil`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `histori`
--
ALTER TABLE `histori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `jenjang`
--
ALTER TABLE `jenjang`
  MODIFY `id_jenjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `kontak`
--
ALTER TABLE `kontak`
  MODIFY `id_kontak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pengumuman`
--
ALTER TABLE `pengumuman`
  MODIFY `id_pengumuman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id_siswa` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
