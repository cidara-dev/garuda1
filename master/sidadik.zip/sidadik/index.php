<?php
require "config/database.php";
require "config/function.php";
require "config/functions.crud.php";
require "login/versi.php";
$tahun1 = date('Y');
$tahun2 = date('Y')+1;
?>

<?php if ($setting['ppdb'] == 1) { ?>
	

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport" />
         <title>PPDB ONLINE | <?= $setting['nama_sekolah'] ?></title>
		 <!-- META DISKRIPSI-->
		<meta name="description" content="Mari bergabung Bersama Kami di <?= $setting['nama_sekolah'] ?>, Pendaftaran Peserta didik Baru Tahun <?= date('Y') ?> Kembali dibuka ">
		<meta name="keywords" content="ppdb online,Pendaftaran Siswa Baru,"/>
		<meta name="msapplication-navbutton-color" content="#4285f4">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
		<meta name="msapplication-TileColor" content="#ffffff">
		
		<meta name="theme-color" content="#ffffff">
		<link rel="stylesheet" href="assets/modules/izitoast/css/iziToast.min.css">
        <link href="assets/css/front.min.css" rel="stylesheet" />
        <link rel="shortcut icon" href="<?= $setting['logo'] ?>" >		
		 <link rel="stylesheet" href="assets/css/1.css">
		 <link rel="stylesheet" href="assets/css/2.css">
		 <link rel="stylesheet" href="assets/css/3.css">
		
		 <link rel="stylesheet" href="assets/css/components2.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    
    <!-- Start GA -->
    
    
	 
    </head>
    
    <body data-spy="scroll" data-target="#menu" data-offset="100">
        <div class="home-wrapper" id="home">
            <div class="home-header">
                <div class="container p-0">
                    <nav class="navbar navbar-expand-lg navbar-light" id="navbar-header">
                        <a class="navbar-brand" href="javascript:;">
                            <img src="<?= $setting['logo'] ?>" height="75" />
                            <div class="home-header-text d-none d-sm-block">
                                <h5>PENERIMAAN PESERTA DIDIK BARU</h5>
                                <h6><?= $setting['nama_sekolah'] ?></h6>
                                <h6>Tahun <?= $tahun1 ?></h6>
                            </div>
                            <span class="logo-mini-unbk d-block d-sm-none">PPDB </span>
                            <span class="logo-mini-tahun d-block d-sm-none">_ONLINE</span>
                        </a>
                        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="menu">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link" href="#home" id="link-home">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#tentang" id="link-tentang">Daftar</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#statistik" id="link-statistik">Statistik</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#persyaratan" id="link-persyaratan">Info Pendaftaran</a>
                                </li>
								<li class="nav-item">
                                    <a class="nav-link" href="datadaftar.php" id="link-persyaratan">Data Pendaftar</a>
                                </li>
								 <li class="nav-item">
                                    <a class="nav-link" href="./login" id="link-persyaratan">Admin</a>
                                </li>
								
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
		
            <div class="home-banner">
                <div class="home-banner-bg home-banner-bg-color"></div>
                <div class="home-banner-bg home-banner-bg-img"></div>
                <div class="container mt-5">
                    <div class="row">
                        
						<div class="col-sm-8">
                            <div id="carousel" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li data-target="#carousel" data-slide-to="0" class="active"></li>
                                    <li data-target="#carousel" data-slide-to="1"></li>
                                    <li data-target="#carousel" data-slide-to="2"></li>
                                   
                                    
                                </ol>
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <div>
                                            <h5 data-animation="animated fadeInDownBig">
                                                Selamat Datang Di web PPDB Online
                                            </h5>
                                            <br />
                                            <p data-animation="animated slideInRight" data-delay="1s">
                                                Aplikasi Penerimaan Peserta didik baru Tahun Pelajaran <?= $tahun1 ?> / <?= $tahun2 ?> <?= $setting['nama_sekolah'] ?>.
                                            </p>
                                            <p data-animation="animated slideInRight" data-delay="2s">
                                                Pendaftaran Siswa dan Siswi Baru Tahun <?= $tahun1 ?> ini telah dibuka. Silahkan Segera Daftar dan lengkapi Formulir
                                            </p>
                                            <p data-animation="animated flipInX" data-delay="3s">
                                                <a href="/#tentang" class="btn btn-warning nav-link">
                                                    Lihat Alur Pendaftaran
                                                    <span class="fa fa-chevron-down"></span>
                                                </a>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <div>
                                            <h5 data-animation="animated fadeInDownBig">
                                                Syarat Pendaftaran Peserta Didik Baru
                                            </h5>
                                            <h5 data-animation="animated fadeInDownBig">
                                                Tahun Pelajaran <?= $tahun1 ?> / <?= $tahun2 ?>
                                            </h5>
                                            <ul>
                                                <li data-animation="animated fadeInDownBig" data-delay="1s">
                                                    Surat Keterangan Lulus
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="2s">
                                                    Ijazah Jenjang Sebelumnya
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="3s">
                                                    Kartu Keluarga
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="4s">
                                                    Akta Kelahiran
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="5s">
                                                    Scan Raport
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <div>
                                            <h5 data-animation="animated fadeInDownBig">
                                                Alur Pendaftaran Peserta Didik Baru
                                            </h5>
                                            <h5 data-animation="animated fadeInDownBig">
                                                Tahun Pelajaran <?= $tahun1 ?> / <?= $tahun2 ?>
                                            </h5>
                                            <ul>
                                                <li data-animation="animated fadeInDownBig" data-delay="1s">
                                                    Daftar Akun
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="2s">
                                                    Lengkapi Formulir
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="3s">
                                                    Upload Berkas
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="4s">
                                                    Pembayaran
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="5s">
                                                    Download Berkas
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                   
                                    
                                    
                                </div>
                            </div>
							
                        </div>
                        <div class="col-sm-4">
						
                            <div class="card card-login bg-info">
							
                                <div class="card-body">
								<img src="<?= $setting['logo_ppdb'] ?>" alt=""  width="100%">
									<br>
                                   <form id="form-login">
                                        <div class="form-group">
                                            <span class="fa fa-user"></span>
                                           <input type="text" onkeyup="this.value = this.value.toUpperCase()" class="form-control" name="username" placeholder="Masukkan NISN" required autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <span class="fa fa-key"></span>
                                           <input type="password" class="form-control" name="password" id="inputPassword4" placeholder="Password">
                                        </div>
                                       
                                        <button type="submit" class="btn btn-primary btn-block btn-login" id="btnsimpan">
                                            Masuk
                                        </button>
										 
										  
                                    </form>
									<br>
                                    <a href="#tentang" class="btn btn-primary btn-block btn-login">
                                                    Daftar Disini</a>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="home-content">
                <section id="tentang">
                    <div class="container">
                        
                        <div class="row">
                            
                            <div class="col-sm-6 d-flex align-items-center">
							<div class="col-md-12 animated bounceInLeft">
								<?php if ($setting['jenjang'] == 1) { ?>
								<div class="card">
									<div class="card-header bg-danger">
										<h4>Formulir Pendaftaran</h4>
									</div>
									<form method="post"id="form-daftar">
										<div class="card-body">
											<input type="date" name="tgl_daftar" class="form-control datepicker" value="<?= $daftar['tgl_daftar'] ?>"hidden >
											<div class="form-group">
												<label for="asal">JURUSAN / PEMINATAN</label>
												<select class="form-control select2" style="width: 100%" name="jurusan" id="jurusan" >
													<option value="">Pilih Jurusan</option>
													<?php $qu = mysqli_query($koneksi, "select * from jurusan where status='1'");
													while ($jur = mysqli_fetch_array($qu)) {
													?>
														<option value="<?= $jur['id_jurusan'] ?>"> <?= $jur['nama_jurusan'] ?></option>
													<?php } ?>

												</select>
											</div>
											
											<div class="form-row">
												<div class="form-group col-md-6">
													<label for="jenis">JENIS PENDAFTARAN</label>
													<select class="form-control" name="jenis" id="jenis">
													<option value="1">Siswa Baru</option>
													
												</select>
												</div>
												<input type="hidden" class="form-control datepicker" name="tgl_daftar" required>
												<div class="form-group col-md-6">
													<label for="nisn">Nomor NISN</label>
													<input type="number" maxlength="10" class="form-control" name="nisn" placeholder="NISN" autocomplete="off" required>
												</div>
											</div>

											<div class="form-row">
											<div class="form-group col-md-6">
												<label for="nama">NAMA LENGKAP*</label>
												<input type="text" class="form-control" name="nama_siswa" placeholder="Nama Lengkap" autocomplete="off" required>
											</div>
											<div class="form-group col-md-6">
												<label for="nohp">NO HANDPHONE</label>
												<input type="number" class="form-control" name="nohp" placeholder="No HP Whatsapp" required>
											</div>
											</div>
											
											<div class="form-row">
												<div class="form-group col-md-6">
													<label for="tempat">TEMPAT LAHIR</label>
													<input type="text" class="form-control" name="tempat" required>
												</div>
												<div class="form-group col-md-6">
													<label for="tgllahir">TANGGAL LAHIR</label>
													<input type="date" class="form-control" name="tgllahir" required>
												</div>

											</div>
											<div class="form-group">
												<label for="asal_sekolah">Asal Sekolah</label>
												<input type="text" class="form-control" name="asal_sekolah"  required>
											</div>
											
											<div class="form-group">
												<label for="inputPassword4">PASSWORD (Mohon Diingat!)</label>
												<input type="password" class="form-control" name="password" id="inputPassword4" placeholder="Password" required>
											</div>
											<div class="form-row">
											<div class="form-group col-md-6">
											<a href="#" onclick="document.getElementById('captcha').src = 'securimage/securimage_show.php?' + Math.random(); return false">Refresh Kode</a>

											<img class="p-b-5" id="captcha" src="securimage/securimage_show.php" alt="CAPTCHA Image" style="height:70px" /><br>
											 </div>
												<div class="form-group col-md-6">
													<input class="form-control" type="text" name="kodepengaman" placeholder="masukan kode" required>
												</div>
										   
											 </div>
										</div>
										<div class="card-header bg-white">
											<button id='btnsimpan' type="submit" name="submit" class="btn btn-lg btn-primary">DAFTAR</button>
										</div>
									</form>
								</div>
								<?php } else { ?>
								<div class="card">
									<div class="card-header bg-warning">
										<h4>Formulir Pendaftaran</h4>
									</div>
									<form id="form-daftar2">
										<div class="card-body">
											<input type="date" name="tgl_daftar" class="form-control datepicker" value="<?= $daftar['tgl_daftar'] ?>"hidden >
											<div class="form-row">
												<div class="form-group col-md-6">
													<label for="jenis">JENIS PENDAFTARAN</label>
													<select class="form-control" name="jenis" id="jenis">
													<option value="1">Siswa Baru</option>
													
												</select>
												</div>
												<div class="form-group col-md-6">
													<label for="nisn">Nomor NISN</label>
													<input type="number" maxlength="10" class="form-control" name="nisn" placeholder="NISN" autocomplete="off" required>
												</div>
											</div>

											<div class="form-row">
											<div class="form-group col-md-6">
												<label for="nama">NAMA LENGKAP*</label>
												<input type="text" class="form-control" name="nama_siswa" placeholder="Nama Lengkap" autocomplete="off" required>
											</div>
											<div class="form-group col-md-6">
												<label for="nohp">NO HANDPHONE</label>
												<input type="number" class="form-control" name="nohp" placeholder="No HP Whatsapp" required>
											</div>
											</div>
											
											<div class="form-row">
												<div class="form-group col-md-6">
													<label for="tempat">TEMPAT LAHIR</label>
													<input type="text" class="form-control" name="tempat" required>
												</div>
												<div class="form-group col-md-6">
													<label for="tgllahir">TANGGAL LAHIR</label>
													<input type="date" class="form-control " name="tgllahir" required>
												</div>

											</div>
											<div class="form-group">
												<label for="asal_sekolah">Asal Sekolah</label>
												<input type="text" class="form-control" name="asal_sekolah"  required>
											</div>
											<div class="form-group">
												<label for="inputPassword4">PASSWORD (Mohon Diingat!)</label>
												<input type="password" class="form-control" name="password" id="inputPassword4" placeholder="Password" required>
											</div>
											<div class="form-row">
											<div class="form-group col-md-6">
											<a href="#" onclick="document.getElementById('captcha').src = 'securimage/securimage_show.php?' + Math.random(); return false">Refresh Kode</a>

											<img class="p-b-5" id="captcha" src="securimage/securimage_show.php" alt="CAPTCHA Image" style="height:70px" /><br>
											 </div>
												<div class="form-group col-md-6">
													<input class="form-control" type="text" name="kodepengaman" placeholder="masukan kode" required>
												</div>
										   
											 </div>
										</div>
										<div class="card-footer">
											<button id='btnsimpan' type="submit" class="btn btn-lg btn-primary">SIMPAN DATA</button>
										</div>
									</form>
								</div>
								<?php } ?>
							</div>
                            </div>
							<div class="col-sm-6">
							
                                <div class="container">
                        
                        <div class="row mt-12">
                            <div class="col-sm-12">
                               <div class="card">
								<div class="card-header text-white" style="background-color: #005f6b">
								   <h4>Data Statistik Asal Sekolah Pendaftar</h4>
									
								</div>
								<div class="card-body">
									<div class="table-responsive">
									 <script type="text/javascript">$('#sampleTable1').DataTable();</script>
										 <table style="font-size: 12px" class="table table-striped table-sm" id="sampleTable">
											<thead>
												<tr>
													<th class="text-center">
												 NO
													</th>
													
													<th>NAMA SEKOLAH</th>
													<th class="text-center">PENDAFTAR</th>
												</tr>
											</thead>
											<tbody class="ui-sortable">
												<?php $query = mysqli_query($koneksi, "select * from siswa WHERE jenis = '1' group by asal_sekolah  ");
												 $no = 0;
												while ($sekolah = mysqli_fetch_array($query)) {
													$no++;
													$hitung = rowcount($koneksi, 'siswa', ['asal_sekolah' => $sekolah['asal_sekolah']]);
													
												?>
													<tr>
														
														<td><?= $no; ?></td>
														
														<td><?= $sekolah['asal_sekolah'] ?></td>

														<td class="text-center">
															<div class="badge badge-success"><?= $hitung ?></div>
														</td>
													</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
								 </div> 
								
								
                            </div>
                        </div>
                    </div>	
                            </div>
                        </div>
                    </div>
                </section>
				

                <section class="bg-light statistik" id="statistik">
                    <div class="container">
                        <h5 class="text-center">Data Pendaftar </h5>
                        <h6 class="text-center">Peserta Didik Baru <?= $setting['nama_sekolah'] ?> Tahun <?= $tahun1 ?> / <?= $tahun2 ?></h6>
                        <div class="row mt-12">
                            <div class="col-sm-4">
                                <div class="card mt-2">
                                    <div class="card-header bg-primary">Data Pendaftar</div>
                                    <div class="card-body">
                                        <h2 class="text-center"><?= rowcount($koneksi, 'siswa', ['jenis' => 1]) ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card mt-2">
                                    <div class="card-header bg-secondary">Data Diterima</div>
                                    <div class="card-body">
                                        <h2 class="text-center"><?= rowcount($koneksi, 'siswa', ['status' => 4]) ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card mt-2">
                                    <div class="card-header bg-success">Quota Pendaftar</div>
                                    <div class="card-body">
                                        <h2 class="text-center"><?php $kuota = mysqli_fetch_array(mysqli_query($koneksi, "select *, sum(kuota) as kuota from jurusan"));
                    echo $kuota['kuota']; ?></h2>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                       
                       
                    </div>
                </section>
                 <section class="bg-light statistik" id="persyaratan">
                    <div class="container">
                        <h5 class="text-center">Info Pendaftaran </h5>
                        <h6 class="text-center">Peserta Didik Baru <?= $setting['nama_sekolah'] ?> Tahun <?= $tahun1 ?> / <?= $tahun2 ?></h6>
                        <div class="row mt-12">
                            <div class="col-sm-6">
                                <div class="card mt-2">
                                    <div class="card-header bg-primary">Cara Daftar</div>
                                    <div class="card-body">
									 <div class="col-12 animated bounceIn">
									
										<div class="activities">
											<div class="activity">
												<div class="activity-icon bg-primary text-white shadow-primary">
													1
												</div>
												<div class="activity-detail">
													<p>Calon Siswa mendaftar di web pendaftaran.</p>
													<p><a href="#tentang" class="btn btn-primary btn-block btn-login">
                                                    Klik Disini</a>.</p>
												</div>
											</div>

										</div>
										<div class="activities">
											<div class="activity">
												<div class="activity-icon bg-primary text-white shadow-primary">
													2
												</div>
												<div class="activity-detail">
													<p>Jika selesai pendaftaran silahkan login dengan username dan password saat pendaftaran</p>
													<p><a href="#tentang"class="btn btn-success btn-block btn-login">
                                                    Daftar Disini</a></p>
												</div>
												
											</div>
										</div>
										<div class="activities">
											<div class="activity">
												<div class="activity-icon bg-primary text-white shadow-primary">
													3
												</div>
												<div class="activity-detail">
													<p>Lengkapi Formulir yang diberikan dengan data yang benar.</p>

												</div>
											</div>
										</div>
									</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="card mt-2">
                                    <div class="card-header bg-secondary">Pengumuman</div>
                                    <div class="card-body">
                                      <div class="row">
										<div class="col-12 animated bounceIn">
											<div class="card">
												
												<div class="card-body">
													<div class="activities">
														<?php $query = mysqli_query($koneksi, "SELECT * FROM pengumuman where jenis='2'");
														while ($data = mysqli_fetch_array($query)) {
														?>
															<div class="activity">
																<div class="activity-icon bg-primary text-white shadow-primary">
																	<i class="fas fa-bullhorn"></i>
																</div>
																<div class="activity-detail">
																	<div class="mb-2">
																		<span class="text-job text-primary"><?= $data['tgl'] ?></span>
																		<span class="bullet"></span>
																		<a class="text-job" href="#">View</a>

																	</div>
																	<h5><?= $data['judul'] ?></h5>
																	<p><?= $data['pengumuman'] ?></p>
																</div>
															</div>
														<?php } ?>

													</div>
												</div>
											</div>
										</div>
									</div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
				
				
				
				
				

				
				
				
            </div>
			
			
			
            
        </div>
		<div class="home-footer"><div class="container text-center">Copyright ©<?= date('Y') ?> <?= $setting['nama_sekolah'] ?> | <?= $create ?></div>
        <script>
            var baseURL = '/';
            
        </script>
		
		<script src="vendor/jquery-3.2.1.min.js"></script>
        <script src="vendor/jquery.form.min.js"></script>
        <script src="vendor/bootstrap.min.js"></script>
        <script src="vendor/popper.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		<script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript">$('#sampleTable').DataTable();</script>
			
		
		
		
        <!-- Vendor -->
        
        
        
        <script src="vendor/wow.min.js"></script>
        
        <!-- Assets -->
        <script src="vendor/front.min.js"></script>
       
    </body>
</html>
<script>
    $('#form-login').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'crud_web.php?pg=login',
            data: $(this).serialize(),
            beforeSend: function() {
                $('#btnsimpan').prop('disabled', true);
            },
            success: function(data) {
                var json = $.parseJSON(data);
                $('#btnsimpan').prop('disabled', false);
                if (json.pesan == 'ok') {
                    iziToast.success({
                        title: 'Mantap!',
                        message: 'Login Berhasil',
                        position: 'topRight'
                    });
                    setTimeout(function() {
                        window.location.href = "user";
                    }, 2000);

                } else {
                    iziToast.error({
                        title: 'Maaf!',
                        message: json.pesan,
                        position: 'topCenter'
                    });
                }
                //$('#bodyreset').load(location.href + ' #bodyreset');
            }
        });
        return false;
    });
	
    
    
</script>
<script>
    $('#form-daftar').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'crud_web.php?pg=simpan',
            data: $(this).serialize(),
            beforeSend: function() {
                $('#btnsimpan').prop('disabled', true);
            },
            success: function(data) {
                var json = $.parseJSON(data);
                $('#btnsimpan').prop('disabled', false);
                if (json.pesan == 'ok') {
                    iziToast.success({
                        title: 'Mantap!',
                        message: 'Data berhasil disimpan',
                        position: 'topRight'
                    });
                    setTimeout(function() {
                        $('#home').load('konfirmasi.php?id=' + json.id + '&nisn=' + json.nisn + '&pass=' + json.pass + '&nama=' + json.nama);
                    }, 2000);

                } else {
                    iziToast.error({
                        title: 'Maaf!',
                        message: json.pesan,
                        position: 'topCenter'
                    });
                    document.getElementById('captcha').src = 'securimage/securimage_show.php?' + Math.random();

                }
                //$('#bodyreset').load(location.href + ' #bodyreset');
            }
        });
        return false;
    });
    
</script>
<script>
    $('#form-daftar2').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'crud_web.php?pg=simpan2',
            data: $(this).serialize(),
            beforeSend: function() {
                $('#btnsimpan').prop('disabled', true);
            },
            success: function(data) {
                var json = $.parseJSON(data);
                $('#btnsimpan').prop('disabled', false);
                if (json.pesan == 'ok') {
                    iziToast.success({
                        title: 'Mantap!',
                        message: 'Data berhasil disimpan',
                        position: 'topRight'
                    });
                    setTimeout(function() {
                        $('#home').load('konfirmasi.php?id=' + json.id + '&nisn=' + json.nisn + '&pass=' + json.pass + '&nama=' + json.nama);
                    }, 2000);

                } else {
                    iziToast.error({
                        title: 'Maaf!',
                        message: json.pesan,
                        position: 'topCenter'
                    });
                    document.getElementById('captcha').src = 'securimage/securimage_show.php?' + Math.random();

                }
                //$('#bodyreset').load(location.href + ' #bodyreset');
            }
        });
        return false;
    });
    
</script>

	
	
	
<?php } else { ?>


	

<!DOCTYPE html>

<html lang="en" translate="no">
<head>
<base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="google" content="notranslate" />
    <meta name="description" content="Aplikasi Database | <?= $setting['nama_sekolah'] ?>">
    <meta name="author" content="Nasrul Creative">
	<meta name="theme-color" content="#317EFB"/>
    <meta name="keyword" content="Aplikasi database,database madrasah,database sekolah">
	<meta name="msapplication-navbutton-color" content="#4285f4">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="msapplication-TileColor" content="#ffffff">
    
    <meta name="theme-color" content="#ffffff">
	
    <title>DATABASE| <?= $setting['nama_sekolah'] ?> </title>
   
    <link rel="icon" type="image/png" sizes="192x192" href="assets/database.png">
		<link rel="stylesheet" href="assets/modules/izitoast/css/iziToast.min.css">
        <link href="assets/css/front2.min.css" rel="stylesheet" />
        <link rel="shortcut icon" href="<?= $setting['logo'] ?>" >		
		 <link rel="stylesheet" href="assets/css/1.css">
		 <link rel="stylesheet" href="assets/css/2.css">
		 <link rel="stylesheet" href="assets/css/3.css">
		
		 <link rel="stylesheet" href="assets/css/components2.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
<style>
        @media screen and (max-width: 360px){
            #rc-imageselect, .g-recaptcha {transform:scale(0.66);-webkit-transform:scale(0.66);transform-origin:0 0;-webkit-transform-origin:0 0;}
        }
        @media screen and (min-width: 361px,max-width: 720px){
            #rc-imageselect, .g-recaptcha {transform:scale(0.88);-webkit-transform:scale(0.88);transform-origin:0 0;-webkit-transform-origin:0 0;}
        }
    </style>
    <style >
.pre-loader {
    background: #fff;
    background-position: center center;
    background-size: 13%;
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 12345;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center
}

.pre-loader .loader-logo {
    padding-bottom: 15px;
}

.pre-loader .loader-progress {
    height: 8px;
    border-radius: 15px;
    max-width: 200px;
    margin: 0 auto;
    display: block;
    background: #ecf0f4;
    overflow: hidden
}

.pre-loader .bar {
    width: 0%;
    height: 8px;
    display: block;
    background: #1b00ff
}

.pre-loader .percent {
    text-align: center;
    font-size: 24px;
}

.pre-loader .loading-text {
    text-align: center;
    font-size: 18px;
    font-weight: 500;
    padding-top: 15px
}

		</style>    
    </head>
 
<div class="pre-loader">
<div class="pre-loader-box">
  <div class="loader-logo"><img src="assets/back/loading.gif" width="160px" alt=""></div>
  <div class="loader-progress" id="progress_div">
    <div class="bar" id="bar1" style="width: 100%;"></div>
  </div>
  <div class="percent" id="percent1">100%</div>
  <div class="loading-text">
    Mohon Menunggu...
  </div>
</div>
</div>
 
    <body data-spy="scroll" data-target="#menu" data-offset="100">
        <div class="home-wrapper" id="home">
            <div class="home-header">
                <div class="container p-0">
                    <nav class="navbar navbar-expand-lg navbar-light" id="navbar-header">
                        <a class="navbar-brand" href="javascript:;">
                            <img src="<?= $setting['logo'] ?>" height="75" />
							
							
                            <div class="home-header-text d-none d-sm-block">
                                <h5>APLIKASI DATABASE SISWA</h5>
                                <h6><?= $setting['nama_sekolah'] ?></h6>
                                <h6>Tahun Pelajaran <?= $tahun1 ?>/<?= $tahun2 ?></h6>
                            </div>
                            <span class="logo-mini-unbk d-block d-sm-none">DATABASE </span>
                            <span class="logo-mini-tahun d-block d-sm-none">_ONLINE</span>
                        </a>
						
						
						
						<hr>
						
                        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="menu">
                           
							<ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link" href="#home" id="link-home">Home</a>
                                </li>
								
                                <li class="nav-item">
                                    <a class="nav-link" href="datasiswa.php" id="link-tentang">Data Siswa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="dataalumni.php" id="link-statistik">Data Alumni</a>
                                </li>
                               
								 <li class="nav-item">
                                    <a class="nav-link" href="./login" id="link-persyaratan">Admin</a>
                                </li>
								
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
		
            <div class="home-banner">
                <div class="home-banner-bg home-banner-bg-color"></div>
                <div class="home-banner-bg home-banner-bg-img"></div>
                <div class="container mt-5">
                    <div class="row">
                        
						<div class="col-sm-7">
                            <div id="carousel" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li data-target="#carousel" data-slide-to="0" class="active"></li>
                                    <li data-target="#carousel" data-slide-to="1"></li>
                                    
                                   
                                    
                                </ol>
                                <div class="carousel-inner">
                                   
                                   <div class="carousel-item active">
                                        <div>
                                            <h5 data-animation="animated fadeInDownBig">
                                                Selamat Datang Di Aplikasi Database Siswa Online
                                            </h5>
                                            <h5 data-animation="animated fadeInDownBig">
                                                Tahun Pelajaran <?= $tahun1 ?> / <?= $tahun2 ?>
                                            </h5>
                                            <ul>
                                                <li data-animation="animated fadeInDownBig" data-delay="1s">
                                                    Database Siswa
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="2s">
                                                    Database Guru
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="3s">
                                                    Database Alumni
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="4s">
                                                    Administrasi Mutasi
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="5s">
                                                    Buku Induk Siswa
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="carousel-item">
                                        <div>
                                            <h5 data-animation="animated fadeInDownBig">
                                                Aplikasi Ini Mencakup Beberapa Fitur Diantaranya
                                            </h5>
                                            
                                            <ul>
                                                <li data-animation="animated fadeInDownBig" data-delay="1s">
                                                    Mutasi Siswa
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="2s">
                                                    Buku Induk Siswa
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="3s">
                                                    Cetak Administrasi Siswa
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="4s">
                                                    Cetak Kartu NISN
                                                </li>
                                                <li data-animation="animated flipInX" data-delay="5s">
                                                    Arsip Data Alumni
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                   
                                    
                                    
                                </div>
                            </div>
							
                        </div>
                        <div class="col-sm-5 d-none d-sm-block">
						
                            <img src="assets/banner.webp" height="350" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="home-content">
                
				

                <section class="bg-light statistik" id="statistik">
                    <div class="container">
                        <h5 class="text-center">Informasi Data </h5>
                        <h6 class="text-center"><?= $setting['nama_sekolah'] ?> Tahun <?= $tahun1 ?> / <?= $tahun2 ?></h6>
                        <div class="row mt-12">
                            <div class="col-sm-4">
                                <div class="card mt-2">
                                    <div class="card-header bg-primary">Data Siswa</div>
                                    <div class="card-body">
                                        <h2 class="text-center"><?= rowcount($koneksi, 'siswa', ['status' => 1]) ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card mt-2">
                                    <div class="card-header bg-secondary">Data Alumni</div>
                                    <div class="card-body">
                                        <h2 class="text-center"><?= rowcount($koneksi, 'siswa', ['status' => 3]) ?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card mt-2">
                                    <div class="card-header bg-success">Data PTK</div>
                                    <div class="card-body">
                                        <h2 class="text-center"><?= rowcount($koneksi, 'user', ['level' => 'gtk']) ?></h2>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                       
                       
                    </div>
                </section>
				
                 <section class="bg-light statistik" id="persyaratan">
                    <div class="container">
                        <h5 class="text-center">Info Pendaftaran </h5>
                        <h6 class="text-center">Peserta Didik Baru <?= $setting['nama_sekolah'] ?> Tahun <?= $tahun1 ?> / <?= $tahun2 ?></h6>
                        <div class="row mt-12">
                            <div class="col-sm-6">
                                <div class="card mt-2">
                                    <div class="card-header bg-primary">Cara Daftar</div>
                                    <div class="card-body">
									 <div class="col-12 animated bounceIn">
									
										<div class="activities">
											<div class="activity">
												<div class="activity-icon bg-primary text-white shadow-primary">
													1
												</div>
												<div class="activity-detail">
													<p>Calon Siswa mendaftar di web pendaftaran.</p>
													<p><a href="#tentang" class="btn btn-primary btn-block btn-login">
                                                    Klik Disini</a>.</p>
												</div>
											</div>

										</div>
										<div class="activities">
											<div class="activity">
												<div class="activity-icon bg-primary text-white shadow-primary">
													2
												</div>
												<div class="activity-detail">
													<p>Jika selesai pendaftaran silahkan login dengan username dan password saat pendaftaran</p>
													<p><a href="#tentang"class="btn btn-success btn-block btn-login">
                                                    Daftar Disini</a></p>
												</div>
												
											</div>
										</div>
										<div class="activities">
											<div class="activity">
												<div class="activity-icon bg-primary text-white shadow-primary">
													3
												</div>
												<div class="activity-detail">
													<p>Lengkapi Formulir yang diberikan dengan data yang benar.</p>

												</div>
											</div>
										</div>
									</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="card mt-2">
                                    <div class="card-header bg-secondary">Pengumuman</div>
                                    <div class="card-body">
                                      <div class="row">
										<div class="col-12 animated bounceIn">
											<div class="card">
												
												<div class="card-body">
													<div class="activities">
														<?php $query = mysqli_query($koneksi, "SELECT * FROM pengumuman where jenis='2'");
														while ($data = mysqli_fetch_array($query)) {
														?>
															<div class="activity">
																<div class="activity-icon bg-primary text-white shadow-primary">
																	<i class="fas fa-bullhorn"></i>
																</div>
																<div class="activity-detail">
																	<div class="mb-2">
																		<span class="text-job text-primary"><?= $data['tgl'] ?></span>
																		<span class="bullet"></span>
																		<a class="text-job" href="#">View</a>

																	</div>
																	<h5><?= $data['judul'] ?></h5>
																	<p><?= $data['pengumuman'] ?></p>
																</div>
															</div>
														<?php } ?>

													</div>
												</div>
											</div>
										</div>
									</div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
				
				
				
				
				

				
				
				
            </div>
			
			
			
            
        </div>
		<div class="home-footer"><div class="container text-center">Copyright ©<?= date('Y') ?> <?= $setting['nama_sekolah'] ?> | <?= $create ?></div>
        <script>
            var baseURL = '/';
            
        </script>
		<script src="vendor/jquery-3.2.1.min.js"></script>
        <script src="vendor/jquery.form.min.js"></script>
        <script src="vendor/bootstrap.min.js"></script>
        <script src="vendor/popper.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		<script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript">$('#sampleTable').DataTable();</script>
			
		
		
		
        <!-- Vendor -->
        
        
        
        <script src="vendor/wow.min.js"></script>
        
        <!-- Assets -->
        <script src="vendor/front.min.js"></script>
        <!-- Assets -->
       
    </body>

	
<?php } ?>
<script>
  $(document).ready(function() {
	var elapsedTime = 0;
	var interval = setInterval(function() {
	  timer()
	}, 10);

	function progressbar(percent) {
	  document.getElementById("bar1").style.width = percent + '%';
	  document.getElementById("percent1").innerHTML = percent + '%';
	}

	function timer() {
	  if (elapsedTime > 100) {
      var RDMData = decodeURIComponent(getCookie("rdmData"));
      if(RDMData !==""){
        var login = JSON.parse(RDMData);
        if(login.status !==""){
          clearInterval(interval);
         
        }
      }
      if (elapsedTime >= 107) {
        clearInterval(interval);
        $(".pre-loader").hide();
      }
	  } else {
		  progressbar(elapsedTime);
	  }
	  elapsedTime++;
	}
	//setTimeout(function(){ $(".pre-loader").hide(); }, 2000);
  function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }	


});


  </script>
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "<?= $setting['nolivechat'] ?>", // WhatsApp number
            email: "<?= $setting['email'] ?>", // Email
            call_to_action: "Hubungi Kami!!!", // Call to action
            button_color: "#129BF4", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "whatsapp,email", // Order of buttons
            pre_filled_message: "<?= $setting['livechat'] ?>", // WhatsApp pre-filled message
        };
        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
