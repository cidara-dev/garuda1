<?php
require "config/database.php";
require "config/function.php";
require "config/functions.crud.php";
require "login/versi.php";
$tahun1 = date('Y');
$tahun2 = date('Y')+1;
?>

<!DOCTYPE html>
<html>
<head>
<base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="google" content="notranslate" />
    <meta name="description" content="Aplikasi Database | <?= $setting['nama_sekolah'] ?>">
    <meta name="author" content="Nasrul Creative">
	<meta name="theme-color" content="#317EFB"/>
    <meta name="keyword" content="Aplikasi database,database madrasah,database sekolah">
	<meta name="msapplication-navbutton-color" content="#4285f4">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="msapplication-TileColor" content="#ffffff">
    
    <meta name="theme-color" content="#ffffff">
	
    <title>DATA SISWA | <?= $setting['nama_sekolah'] ?> </title>
   
		<link rel="icon" type="image/png" sizes="192x192" href="assets/database.png">
		
		<link rel="stylesheet" type="text/css" href="css/main2.css">
		<meta name="keywords" content="simasapp v.1.1,simas madrasah, simas sekolah, web simas,"/>
		<link rel="stylesheet" href="assets/modules/izitoast/css/iziToast.min.css">
        <link href="assets/css/front2.min.css" rel="stylesheet" />
        <link rel="shortcut icon" href="<?= $setting['logo'] ?>" >		
		 <link rel="stylesheet" href="assets/css/1.css">
		 <link rel="stylesheet" href="assets/css/2.css">
		 <link rel="stylesheet" href="assets/css/3.css">
		
		 <link rel="stylesheet" href="assets/css/components2.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<!--===============================================================================================-->
	
	 <link href="/assets/img/logo.png" rel="shortcut icon" />
		
	
	
	  <script src="vendor/jquery-3.2.1.min.js"></script>
        <script src="vendor/jquery.form.min.js"></script>
        <script src="vendor/bootstrap.min.js"></script>
        <script src="vendor/popper.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
		<script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript">$('#example').DataTable();</script>
	
	
	<style type="text/css" class="init">
	
	</style>
	<script type="text/javascript" src="/media/js/site.js?_=e469aaf14ac009df7cbcc69a65357089"></script>
	<script type="text/javascript" src="/media/js/dynamic.php?comments-page=extensions%2Fbuttons%2Fexamples%2Finitialisation%2Fexport.html" async></script>
	<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.html5.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.print.min.js"></script>
	<script type="text/javascript" class="init">
	


$(document).ready(function() {
	$('#example').DataTable( {
		dom: 'Bfrtip',
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		]
	} );
} );



	</script>
</head>
<body class="wide comments example">
	
	
	<div class="fw-container">
		
		
		<div class="fw-body">
			<div class="content">
				<h1 class="page_title">File export</h1>
				
				<div class="demo-html">
					<table id="example" class="display nowrap" style="width:100%">
						<thead>
								<tr>
									<th width="30">NO</th>
									<th>Nama Siswa</th>
									
									<th>Jenis Kelamin</th>
									<th width="50">Kelas</th>
								</tr>
							</thead>
							<tbody>
							<?php
													 $query = mysqli_query($koneksi, "select * from siswa where status in(1)");
													$no = 0;
													while ($siswa = mysqli_fetch_array($query)) {
														$kelas = fetch($koneksi, 'jenjang', ['id_jenjang' => $siswa['kelas']]);
														$no++;
														$nisn = $siswa['nisn'];
														$tgl_lahirsiswa = $siswa['tgl_lahir'];
														$tampil_nisn    =substr($nisn, 0, 6);
														
													
													?>
								<tr>
								   <td><?= $no; ?></td>
									<th><?= $siswa['nama_siswa'] ?></td>
									
									<td><?php if ($siswa['jk'] == 'L') { ?> Laki Laki <?php } else { ?> Perempuan <?php } ?></td>
									 <?php if ($siswa['kelas'] == null) { ?>
									 <?php } else { ?>			
									 <td width="50"><?= $kelas['kode'] ?>-<?= $kelas['nama_jenjang'] ?></td>
									 <?php } ?>
								</tr>
								<?php }
													?>
							</tbody>
						
					</table>
				</div>
				
				
					
				
			</div>
		</div>
	</div>
	
	
</body>
</html>